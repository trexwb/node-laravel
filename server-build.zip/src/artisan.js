import 'dotenv/config';
import { bootstrap, container } from './bootstrap/app.js';
import { config } from './bootstrap/configLoader.js';
import { QueueWorker } from './app/Console/Commands/QueueWorker.js';
import { CacheService } from './app/Services/Cache/CacheService.js';
import { Command } from 'commander';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const program = new Command();
const init = async () => {
    const { app } = container;
    await bootstrap(app);
};
program.name('artisan').description('Node Laravel Framework 命令行工具').version('1.0.0');
program
    .command('queue:work')
    .description('启动队列消费者进程')
    .action(async () => {
    await init();
    await QueueWorker.run();
});
program
    .command('cache:clear')
    .description('清除所有缓存')
    .action(async () => {
    await init();
    await CacheService.getDriver().flush();
    console.log('Successfully cleared the cache.');
});
program
    .command('storage:link')
    .description('创建存储目录符号链接')
    .action(async () => {
    const publicPath = path.resolve(__dirname, './public/uploads');
    const storagePath = path.resolve(__dirname, config('app.upload_path'));
    try {
        await fs.unlink(publicPath);
    }
    catch (err) {
        const errLike = err;
        if (errLike.code !== 'ENOENT') {
            try {
                await fs.rm(publicPath, { recursive: true, force: true });
            }
            catch {
                throw err;
            }
        }
    }
    try {
        await fs.mkdir(storagePath, { recursive: true });
        if (process.platform === 'win32') {
            await fs.symlink(storagePath, publicPath, 'junction');
        }
        else {
            await fs.symlink(storagePath, publicPath);
        }
        console.log(`The [${publicPath}] link has been connected to [${storagePath}].`);
    }
    catch (err) {
        const errLike = err;
        if (errLike.code === 'EEXIST') {
            console.warn('The "public/storage" directory already exists.');
        }
        else {
            console.error('Error creating storage link:', errLike.message);
        }
    }
});
program.parse();
//# sourceMappingURL=artisan.js.map