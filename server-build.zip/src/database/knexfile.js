import '../bootstrap/env.js';
import { config } from '../bootstrap/configLoader.js';
const dbConfig = {
    client: 'mysql2',
    connection: {
        host: config('database.host'),
        user: config('database.user'),
        password: config('database.password'),
        database: config('database.database'),
        timezone: '+08:00',
        dateStrings: true,
        enableKeepAlive: true,
        keepAliveInitialDelay: 30000,
    },
    pool: {
        min: 2,
        max: 20,
        idleTimeoutMillis: 60000,
        createTimeoutMillis: 10000,
        acquireTimeoutMillis: 30000,
        afterCreate: (conn, done) => {
            conn.query(`SET time_zone = '+08:00'`, (err) => {
                done(err, conn);
            });
        },
    },
    migrations: {
        tableName: `${config('database.prefix')}migrations`,
        directory: './migrations',
        extension: config('app.env') == 'development' ? 'ts' : 'js',
    },
    seeds: {
        directory: './seeds',
        extension: config('app.env') == 'development' ? 'ts' : 'js',
    },
};
export default dbConfig;
//# sourceMappingURL=knexfile.js.map