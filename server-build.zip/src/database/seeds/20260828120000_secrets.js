import { config } from '../../bootstrap/configLoader.js';
import Utils from '../../app/Helpers/index.js';
import path from 'node:path';
import { fileURLToPath } from 'url';
export async function seed(knex) {
    const __filename = fileURLToPath(import.meta.url);
    const seedFileName = path.basename(__filename, path.extname(__filename));
    const prefix = config('database.prefix');
    const hasRun = await knex(`${prefix}seeds`).where({ name: seedFileName }).first();
    if (hasRun)
        return;
    const countRes = await knex(`${prefix}secrets`).count('id', { as: 'total' }).first();
    const total = Number(countRes?.total || 0);
    if (total === 0) {
        const secretsData = {
            title: '网关',
            app_id: Utils.unique(16).toString(),
            app_secret: Utils.generateRandomString(32),
            app_iv: Utils.generateRandomString(16),
            permissions: JSON.stringify(['admin']),
            extension: JSON.stringify({}),
            status: 1,
            created_at: knex.fn.now(),
            updated_at: knex.fn.now(),
        };
        await knex(`${prefix}secrets`).insert(secretsData);
        console.log('超管网关密钥已初始化成功（演示数据）');
        console.table({ title: secretsData.title, app_id: secretsData.app_id, app_secret: secretsData.app_secret, app_iv: secretsData.app_iv, permissions: secretsData.permissions });
        await knex(`${prefix}seeds`).insert({
            name: seedFileName,
            batch: 1,
            migration_time: knex.fn.now(),
        });
    }
}
//# sourceMappingURL=20260828120000_secrets.js.map