import { config } from '../../bootstrap/configLoader.js';
import path from 'node:path';
import { fileURLToPath } from 'url';
export async function seed(knex) {
    const __filename = fileURLToPath(import.meta.url);
    const seedFileName = path.basename(__filename, path.extname(__filename));
    const prefix = config('database.prefix');
    const hasRun = await knex(`${prefix}seeds`).where({ name: seedFileName }).first();
    if (hasRun)
        return;
    await knex(`${prefix}seeds`).insert({
        name: seedFileName,
        batch: 1,
        migration_time: knex.fn.now(),
    });
}
//# sourceMappingURL=20260828120002_jobs.js.map