import { config } from '../../bootstrap/configLoader.js';
import path from 'node:path';
import { fileURLToPath } from 'url';
export async function seed(knex) {
    const __filename = fileURLToPath(import.meta.url);
    const seedFilePath = path.basename(__filename, path.extname(__filename));
    const prefix = config('database.prefix');
    return await knex(`${prefix}seeds`)
        .where({ name: seedFilePath })
        .first()
        .then(async (row) => {
        if (row)
            return Promise.resolve();
        const total = await knex
            .from(`${prefix}permissions`)
            .count('id', { as: 'total' })
            .first()
            .then((row) => {
            return row.total || 0;
        })
            .catch(() => {
            return 0;
        });
        if (total === 0) {
            const permissions = [
                'secrets',
                'schedules',
                'jobs',
                'seeds',
                'configs',
                'servers',
                'languages',
                'permissions',
                'roles',
                'users',
                'variables',
                'enums',
                'statistics',
                'cache',
                'trash',
            ];
            const permissionObjects = [];
            permissions.forEach((permission) => {
                if (permission.includes('trash')) {
                    ;
                    ['read', 'restore', 'delete'].forEach((action) => {
                        permissionObjects.push({
                            id: null,
                            key: permission,
                            operation: action,
                            extension: null,
                            status: 1,
                            created_at: knex.fn.now(),
                            updated_at: knex.fn.now(),
                            deleted_at: null,
                        });
                    });
                }
                else if (['cache'].includes(permission)) {
                    ;
                    ['read', 'delete'].forEach((action) => {
                        permissionObjects.push({
                            id: null,
                            key: permission,
                            operation: action,
                            extension: null,
                            status: 1,
                            created_at: knex.fn.now(),
                            updated_at: knex.fn.now(),
                            deleted_at: null,
                        });
                    });
                }
                else if (['users'].includes(permission)) {
                    ;
                    ['read', 'write', 'delete', 'impersonate'].forEach((action) => {
                        permissionObjects.push({
                            id: null,
                            key: permission,
                            operation: action,
                            extension: null,
                            status: 1,
                            created_at: knex.fn.now(),
                            updated_at: knex.fn.now(),
                            deleted_at: null,
                        });
                    });
                }
                else {
                    ;
                    ['read', 'write', 'delete'].forEach((action) => {
                        permissionObjects.push({
                            id: null,
                            key: permission,
                            operation: action,
                            extension: null,
                            status: 1,
                            created_at: knex.fn.now(),
                            updated_at: knex.fn.now(),
                            deleted_at: null,
                        });
                    });
                }
            });
            await knex(`${prefix}permissions`)
                .insert(permissionObjects)
                .then(async () => {
                return await knex(`${prefix}seeds`).insert([
                    {
                        name: seedFilePath,
                        batch: 1,
                        migration_time: knex.fn.now(),
                    },
                ]);
            });
        }
    });
}
//# sourceMappingURL=20260828120003_permissions.js.map