import { config } from '../bootstrap/configLoader.js';
import { HealthController } from '../app/Http/Controllers/Front/HealthController.js';
import { ExampleController } from '../app/Http/Controllers/Front/ExampleController.js';
import express, { Router } from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import path from 'node:path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const router = Router();
const WEB_PORT = config('app.web.front.port') || 3000;
const WEB_HOST = config('app.web.front.host') || '0.0.0.0';
const rootPath = path.resolve(__dirname, '../');
const frontDistPath = path.resolve(__dirname, '../../../front/dist');
const paymentDistPath = path.resolve(__dirname, '../../../payment/dist');
router.use('/storage', express.static(path.resolve(rootPath, './storage/uploads')));
router.get('/health', HealthController.healthCheck);
router.get('/example', ExampleController.index);
router.get('/example/:id', ExampleController.show);
router.post('/example', ExampleController.store);
if (WEB_HOST !== 'file') {
    router.get('/payment/{*splat}', createProxyMiddleware({
        target: `http://${WEB_HOST}:9093`,
        changeOrigin: true,
    }));
    router.get('/{*splat}', createProxyMiddleware({
        target: `http://${WEB_HOST}:${WEB_PORT}`,
        changeOrigin: true,
    }));
}
else {
    router.get('/payment/{*splat}', (_req, res, _next) => {
        res.status(200).sendFile(path.resolve(paymentDistPath, 'index.html'));
    });
    router.get('/{*splat}', (_req, res, _next) => {
        res.status(200).sendFile(path.resolve(frontDistPath, 'index.html'));
    });
}
router.use('/', express.static(frontDistPath, {
    fallthrough: true,
}));
export default router;
//# sourceMappingURL=web.js.map