import { config } from '../bootstrap/configLoader.js';
import express, { Router } from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import path from 'node:path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const router = Router();
const WEB_PORT = config('app.web.console.port') || 3000;
const WEB_HOST = config('app.web.console.host') || '0.0.0.0';
const consoleDistPath = path.resolve(__dirname, '../../../console/dist');
if (WEB_HOST !== 'file') {
    router.get('/{*splat}', createProxyMiddleware({
        target: `http://${WEB_HOST}:${WEB_PORT}`,
        changeOrigin: true,
        pathRewrite: {
            '^/': '/console/',
        },
        ws: true,
    }));
}
else {
    router.get('/{*splat}', (_req, res, _next) => {
        res.status(200).sendFile(path.resolve(consoleDistPath, 'index.html'));
    });
}
router.use('/', express.static(consoleDistPath, {
    fallthrough: true,
}));
export default router;
//# sourceMappingURL=console.js.map