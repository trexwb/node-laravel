import { authenticateSecret } from '../app/Http/Middleware/AuthenticateSecret.js';
import { encryptResponse } from '../app/Http/Middleware/EncryptResponse.js';
import { throttle } from '../app/Http/Middleware/Throttle.js';
import { verifySignature } from '../app/Http/Middleware/VerifySignature.js';
import { decryptRequest } from '../app/Http/Middleware/DecryptRequest.js';
import { ExampleUserController } from '../app/Http/Controllers/Api/ExampleUserController.js';
import { Router } from 'express';
export async function createApiRoutes() {
    const router = Router();
    router.use('/', throttle(60, 1), [authenticateSecret, verifySignature, decryptRequest, encryptResponse]);
    router.get('/example/users', ExampleUserController.index);
    router.get('/example/users/:id', ExampleUserController.show);
    return router;
}
//# sourceMappingURL=api.js.map