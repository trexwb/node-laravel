import { ChannelController } from '../app/Http/Controllers/WebSocket/ChannelController.js';
import { WebSocketServer } from 'ws';
export function registerChannels(wss) {
    ChannelController.handleConnection(wss);
}
//# sourceMappingURL=channels.js.map