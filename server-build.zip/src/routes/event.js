import { throttle } from '../app/Http/Middleware/Throttle.js';
import { Router } from 'express';
export async function createEventRoutes() {
    const router = Router();
    router.use('/', throttle(600, 1));
    return router;
}
//# sourceMappingURL=event.js.map