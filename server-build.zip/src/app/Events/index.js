import { registerAllListeners } from '../Listeners/index.js';
import { createLogger } from '../Helpers/logger.js';
const log = createLogger('Events');
export { BaseEvent } from './BaseEvent.js';
export { CacheInvalidated, ScheduleChanged, WriteLogs } from './System/index.js';
export function registerAllEvents() {
    registerAllListeners();
    log.info('All event listeners registered.');
}
//# sourceMappingURL=index.js.map