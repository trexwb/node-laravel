import { BaseEvent } from '../BaseEvent.js';
export class WriteLogs extends BaseEvent {
    static eventName = 'system.write_logs';
    static emit(payload) {
        new WriteLogs(payload).dispatch();
    }
}
//# sourceMappingURL=WriteLogs.js.map