import { BaseEvent } from '../BaseEvent.js';
export class CacheInvalidated extends BaseEvent {
    static eventName = 'system.cache_invalidated';
    static emit(payload) {
        new CacheInvalidated(payload).dispatch();
    }
}
//# sourceMappingURL=CacheInvalidated.js.map