import { BaseEvent } from '../BaseEvent.js';
export class ScheduleChanged extends BaseEvent {
    static eventName = 'system.schedule_changed';
    static emit(payload) {
        new ScheduleChanged(payload).dispatch();
    }
}
//# sourceMappingURL=ScheduleChanged.js.map