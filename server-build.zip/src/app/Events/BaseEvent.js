import { eventBus } from '../../bootstrap/events.js';
export class BaseEvent {
    static eventName;
    payload;
    constructor(payload) {
        this.payload = payload;
    }
    toJSON() {
        return {
            event: this.constructor.eventName,
            timestamp: new Date().toISOString(),
            payload: this.payload,
        };
    }
    dispatch() {
        eventBus.emit(this.constructor.eventName, this.payload);
    }
}
//# sourceMappingURL=BaseEvent.js.map