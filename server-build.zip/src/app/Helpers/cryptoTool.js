import crypto from 'node:crypto';
export class CryptoTool {
    static algorithm = 'aes-256-gcm';
    static _key;
    static _iv;
    static _warnedFallback = false;
    static warnFallback(name) {
        if (!this._warnedFallback) {
            this._warnedFallback = true;
            console.warn(`[CryptoTool] ${name} 未配置，已回退为进程内随机值（重启后已加密数据将无法解密，生产环境必须配置）`);
        }
    }
    static getKey() {
        if (!this._key) {
            const k = process.env.APP_KEY;
            if (!k || !k.trim()) {
                this.warnFallback('APP_KEY');
                this._key = crypto.randomBytes(32);
            }
            else {
                this._key = Buffer.from(k);
            }
        }
        return this._key;
    }
    static getIv() {
        if (!this._iv) {
            const v = process.env.APP_IV;
            if (!v || !v.trim()) {
                this.warnFallback('APP_IV');
                this._iv = crypto.randomBytes(12);
            }
            else {
                this._iv = crypto.createHash('sha256').update(v).digest().subarray(0, 12);
            }
        }
        return this._iv;
    }
    static assertKeyLength(key) {
        if (Buffer.byteLength(key) !== 32) {
            throw new Error('Invalid key or iv length');
        }
    }
    static gcmEncrypt(text, key, iv) {
        this.assertKeyLength(key);
        const cipher = crypto.createCipheriv(this.algorithm, key, iv);
        const ct = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
        const tag = cipher.getAuthTag();
        return iv.toString('hex') + tag.toString('hex') + ct.toString('hex');
    }
    static gcmDecrypt(encoded, key) {
        this.assertKeyLength(key);
        const buf = Buffer.from(encoded, 'hex');
        if (buf.length < 28) {
            throw new Error('Invalid encrypted payload length');
        }
        const iv = buf.subarray(0, 12);
        const tag = buf.subarray(12, 28);
        const ct = buf.subarray(28);
        const decipher = crypto.createDecipheriv(this.algorithm, key, iv);
        decipher.setAuthTag(tag);
        return Buffer.concat([decipher.update(ct), decipher.final()]).toString('utf8');
    }
    static md5(str) {
        const md5 = crypto.createHash('md5');
        md5.update(str);
        return md5.digest('hex');
    }
    static sha256(str) {
        return crypto.createHash('sha256').update(str).digest('hex');
    }
    static hmacSha256(str, key) {
        return crypto.createHmac('sha256', key).update(str).digest('hex');
    }
    static sha1(encryptedData, keyStr = false) {
        return crypto
            .createHmac('sha1', keyStr || this.getKey())
            .update(encryptedData)
            .digest('base64');
    }
    static encrypt(encryptedData, keyStr = false, ivStr = false) {
        if (!encryptedData)
            return;
        const key = keyStr ? Buffer.from(keyStr) : this.getKey();
        const iv = ivStr ? Buffer.from(crypto.createHash('sha256').update(ivStr).digest().subarray(0, 12)) : this.getIv();
        try {
            const encryptedText = typeof encryptedData == 'string' ? encryptedData : JSON.stringify(encryptedData);
            return this.gcmEncrypt(encryptedText, key, iv);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new Error(`Encryption failed: ${errorMessage}`);
        }
    }
    static decrypt(encryptedText, keyStr = false) {
        if (!encryptedText)
            return;
        const key = keyStr ? Buffer.from(keyStr) : this.getKey();
        try {
            const decrypted = this.gcmDecrypt(encryptedText, key);
            if (process.env.APP_DEBUG === 'true') {
                console.debug({
                    encryptedTextLength: encryptedText.length,
                    encryptedPreview: encryptedText.substring(0, 50),
                    decryptedLength: decrypted.length,
                    decryptedPreview: decrypted.substring(0, 100),
                }, 'Decryption details');
            }
            try {
                return JSON.parse(decrypted);
            }
            catch (jsonError) {
                const preview = decrypted.length > 0
                    ? `Decrypted content: "${decrypted.substring(0, 100)}${decrypted.length > 100 ? '...' : ''}"`
                    : 'Decrypted content is empty';
                throw new Error(`Invalid JSON format after decryption. ${preview}`);
            }
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            const additionalInfo = errorMessage.includes('Invalid JSON format')
                ? ''
                : ` | Encrypted input: "${encryptedText.substring(0, 50)}${encryptedText.length > 50 ? '...' : ''}"`;
            throw new Error(`Decryption failed: ${errorMessage}${additionalInfo}`);
        }
    }
    static generateToken(payload) {
        try {
            return this.gcmEncrypt(payload, this.getKey(), this.getIv());
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new Error(`Encryption failed: ${errorMessage}`);
        }
    }
    static decryptToken(encryptedText) {
        try {
            const decrypted = this.gcmDecrypt(encryptedText, this.getKey());
            let decryptedPayload = null;
            try {
                decryptedPayload = JSON.parse(decrypted);
            }
            catch (error) {
                console.error('Failed to parse decrypted token:', error);
            }
            return decryptedPayload;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new Error(`Decryption failed: ${errorMessage}`);
        }
    }
}
//# sourceMappingURL=cryptoTool.js.map