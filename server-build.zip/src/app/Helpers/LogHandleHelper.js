export const logHandle = {
    SecretsUpdate: 'secrets_modify',
    ServerUpdate: 'servers_modify',
    SchedulesTaskRunner: 'schedules_taskRunner',
    OrdersUpdate: 'orders_modify',
    OrderRefundsUpdate: 'orders_refunds_modify',
    authorizeSign: 'authorize_sign',
    authorizeSignOut: 'authorize_sign_out',
};
//# sourceMappingURL=LogHandleHelper.js.map