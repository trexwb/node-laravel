import crypto from 'node:crypto';
import fs from 'node:fs';
export function readKey(options) {
    if (options.key && options.key.trim())
        return options.key.trim();
    if (options.keyPath && options.keyPath.trim()) {
        const p = options.keyPath.trim();
        if (p.includes('-----BEGIN') ||
            (!p.startsWith('/') && !p.startsWith('./') && !p.startsWith('../') && !p.startsWith('~') && p.length > 200)) {
            return p;
        }
        const content = fs.readFileSync(p, 'utf8');
        if (content && content.trim())
            return content.trim();
    }
    throw new Error(`${options.nameForError} is required`);
}
export function normalizeToPem(rawKey) {
    const trimmed = rawKey.trim();
    if (trimmed.includes('-----BEGIN')) {
        return trimmed;
    }
    const b64 = trimmed.replace(/\s+/g, '');
    const lines = b64.match(/.{1,64}/g) || [b64];
    return `-----BEGIN PUBLIC KEY-----\n${lines.join('\n')}\n-----END PUBLIC KEY-----`;
}
export function publicKeyFingerprint(pem) {
    const trimmed = pem.trim();
    let b64 = trimmed;
    if (trimmed.includes('-----BEGIN')) {
        const lines = trimmed.split('\n');
        b64 = lines.filter((l) => !l.includes('-----BEGIN') && !l.includes('-----END')).join('');
    }
    b64 = b64.replace(/\s+/g, '');
    return crypto.createHash('sha256').update(b64).digest('hex').substring(0, 16);
}
//# sourceMappingURL=readKey.js.map