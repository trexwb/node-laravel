export const isEmpty = (value) => {
    if (value === null || value === undefined)
        return true;
    if (typeof value === 'string' && trim(value) === '')
        return true;
    if (Array.isArray(value) && value.length === 0)
        return true;
    if (typeof value === 'object' && Object.keys(value).length === 0)
        return true;
    return false;
};
const trim = (value) => {
    return value.replace(/(^\s*)|(\s*$)/g, '');
};
export const toSafeInteger = (value) => {
    if (typeof value === 'number' && !isNaN(value)) {
        return Number.isInteger(value) ? value : Math.floor(value);
    }
    if (typeof value === 'string' && value.trim() !== '') {
        const parsed = parseFloat(value);
        return isNaN(parsed) ? 0 : Math.floor(parsed);
    }
    return 0;
};
export const toSafeFloat = (value, decimals) => {
    if (typeof value === 'number' && !isNaN(value)) {
        return decimals !== undefined ? Number(value.toFixed(decimals)) : value;
    }
    if (typeof value === 'string' && value.trim() !== '') {
        const parsed = parseFloat(value);
        const result = isNaN(parsed) ? 0 : parsed;
        return decimals !== undefined ? Number(result.toFixed(decimals)) : result;
    }
    return 0;
};
export const toSafeBoolean = (value, strict = false) => {
    if (typeof value === 'boolean')
        return value;
    if (strict) {
        return value === true || value === 'true' || value === 1 || value === '1';
    }
    return !isEmpty(value);
};
export const filterEmptyValues = (obj, options) => {
    const { recursive = false, treatZeroAsEmpty = false, customIsEmpty } = options ?? {};
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
        if (customIsEmpty?.(value)) {
            continue;
        }
        if (value === null || value === undefined) {
            continue;
        }
        if (typeof value === 'string' && value.trim() === '') {
            continue;
        }
        if (typeof value === 'number' && value === 0 && treatZeroAsEmpty) {
            continue;
        }
        if (recursive && value && typeof value === 'object' && !Array.isArray(value)) {
            result[key] = filterEmptyValues(value, options);
        }
        else {
            result[key] = value;
        }
    }
    return result;
};
export const normalizeSort = (sort, allowedColumns) => {
    if (!sort)
        return undefined;
    const match = sort.match(/^([+-])(.*?)$/);
    if (!match)
        return undefined;
    const [, direction, column] = match;
    if (!allowedColumns.includes(column)) {
        return undefined;
    }
    return {
        column,
        order: direction === '-' ? 'DESC' : 'ASC',
    };
};
export const isValidEmail = (email) => {
    if (!email || typeof email !== 'string')
        return false;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};
export const isValidMobile = (mobile) => {
    const strMobile = mobile.toString();
    const mobileRegex = /^1[3-9]\d{9}$/;
    return mobileRegex.test(strMobile);
};
export const isValidIdCard = (idCard) => {
    if (!idCard || typeof idCard !== 'string')
        return false;
    const idCardRegex = /^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/;
    return idCardRegex.test(idCard);
};
export const isValidUrl = (url) => {
    if (!url || typeof url !== 'string')
        return false;
    try {
        new URL(url);
        return true;
    }
    catch {
        return false;
    }
};
export const isValidAmount = (amount) => {
    const numAmount = toSafeFloat(amount, 2);
    return numAmount >= 0;
};
export const mergeUnique = (arr1, arr2) => {
    const combined = arr2 ? [...arr1, ...arr2] : arr1;
    return [...new Set(combined)];
};
export const camelToSnake = (str) => {
    return str.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
};
export const snakeToCamel = (str) => {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
};
export const convertKeysToSnake = (obj) => {
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
        const snakeKey = camelToSnake(key);
        result[snakeKey] = value;
    }
    return result;
};
export const convertKeysToCamel = (obj) => {
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
        const camelKey = snakeToCamel(key);
        result[camelKey] = value;
    }
    return result;
};
//# sourceMappingURL=validation.js.map