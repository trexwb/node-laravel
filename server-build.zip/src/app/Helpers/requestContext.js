import { AsyncLocalStorage } from 'node:async_hooks';
export const requestContext = new AsyncLocalStorage();
export function getTraceId() {
    return requestContext.getStore()?.traceId ?? 'N/A';
}
//# sourceMappingURL=requestContext.js.map