import { randomBytes } from 'node:crypto';
import Utils from './index.js';
const DEFAULT_SENSITIVE_FIELDS = ['password', 'salt', 'secret', 'rememberToken', 'remember_token'];
export const sanitize = (data, options) => {
    const fieldsToRemove = options?.fields ?? DEFAULT_SENSITIVE_FIELDS;
    const recursive = options?.recursive ?? true;
    if (Array.isArray(data)) {
        return data.map((item) => (typeof item === 'object' && item !== null ? sanitizeObject(item, fieldsToRemove, recursive) : item));
    }
    return sanitizeObject(data, fieldsToRemove, recursive);
};
const sanitizeObject = (obj, fieldsToRemove, recursive) => {
    if (!obj || typeof obj !== 'object')
        return obj;
    const sanitized = {};
    for (const [key, value] of Object.entries(obj)) {
        if (fieldsToRemove.includes(key)) {
            continue;
        }
        if (recursive && value && typeof value === 'object' && !Array.isArray(value)) {
            sanitized[key] = sanitizeObject(value, fieldsToRemove, recursive);
        }
        else if (recursive && Array.isArray(value)) {
            sanitized[key] = value.map((item) => (typeof item === 'object' ? sanitizeObject(item, fieldsToRemove, recursive) : item));
        }
        else {
            sanitized[key] = value;
        }
    }
    return sanitized;
};
export const randomString = (length = 6, charset) => {
    const characters = charset ?? 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const bytes = randomBytes(length);
    const result = [];
    for (let i = 0; i < length; i++) {
        result.push(characters.charAt(bytes[i] % characters.length));
    }
    return result.join('');
};
export const uuid = () => {
    return Utils.getUUID();
};
export const generateSerialNumber = (groupSize = 5, numberOfGroups = 4, prefix = 'SN') => {
    const possibleChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const totalLength = groupSize * numberOfGroups;
    const randomPart = [];
    for (let i = 0; i < totalLength; i++) {
        randomPart.push(possibleChars.charAt(Math.floor(Math.random() * possibleChars.length)));
    }
    const groups = [];
    for (let i = 0; i < randomPart.length; i += groupSize) {
        groups.push(randomPart.slice(i, i + groupSize).join(''));
    }
    return prefix ? `${prefix}-${groups.join('-')}` : groups.join('-');
};
export const trim = (value) => {
    if (typeof value !== 'string')
        return value;
    return value.replace(/(^\s*)|(\s*$)/g, '');
};
export const trimAll = (value) => {
    if (typeof value !== 'string')
        return value;
    return value.replace(/\s+/g, '');
};
export const replaceAll = (text, search, replacement) => {
    if (typeof text !== 'string' || typeof search !== 'string' || typeof replacement !== 'string') {
        return text;
    }
    return text.replace(new RegExp(search, 'gm'), replacement);
};
export const camelToSnake = (str) => {
    return str.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
};
export const snakeToCamel = (str) => {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
};
export const camelToSnakeKeys = (obj) => {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj))
        return obj;
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
        result[camelToSnake(key)] = value;
    }
    return result;
};
export const camelToSnakeKeysArr = (arr) => {
    return arr.map((item) => camelToSnakeKeys(item));
};
export const capitalize = (str) => {
    if (!str || str.length === 0)
        return str;
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};
export const maskMobile = (mobile) => {
    if (typeof mobile !== 'string' && typeof mobile !== 'number')
        return mobile;
    const strMobile = mobile.toString();
    return strMobile.length === 11 ? strMobile.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2') : strMobile;
};
export const maskEmail = (email) => {
    if (!email || !email.includes('@'))
        return email;
    const [username, domain] = email.split('@');
    if (username.length <= 2)
        return email;
    const maskedUsername = username.charAt(0) + '*'.repeat(username.length - 2) + username.charAt(username.length - 1);
    return `${maskedUsername}@${domain}`;
};
//# sourceMappingURL=string.js.map