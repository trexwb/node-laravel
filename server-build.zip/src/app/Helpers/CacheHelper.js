export class CacheKeyBuilder {
    prefix;
    parts = [];
    constructor(prefix) {
        this.prefix = prefix;
    }
    addId(id) {
        this.parts.push(`id:${id}`);
        return this;
    }
    addUuid(uuid) {
        this.parts.push(`uuid:${uuid}`);
        return this;
    }
    addToken(token) {
        this.parts.push(`token:${token}`);
        return this;
    }
    addAccount(account) {
        this.parts.push(`account:${account}`);
        return this;
    }
    addList(params) {
        this.parts.push(`list:${this.serialize(params)}`);
        return this;
    }
    addGraph(graphExpr) {
        this.parts.push(`graph:${graphExpr}`);
        return this;
    }
    addTrashed(trashed) {
        if (trashed) {
            this.parts.push('trashed:1');
        }
        return this;
    }
    addCustom(key, value) {
        this.parts.push(`${key}:${this.serialize(value)}`);
        return this;
    }
    build() {
        if (this.parts.length === 0) {
            return this.prefix;
        }
        return `${this.prefix}[${this.parts.join(',')}]`;
    }
    serialize(params) {
        if (!params)
            return '';
        const sortObject = (obj) => {
            if (!obj || typeof obj !== 'object')
                return obj;
            if (Array.isArray(obj)) {
                return obj.map((item) => (typeof item === 'object' && item !== null ? sortObject(item) : item));
            }
            const sortedObj = {};
            const source = obj;
            Object.keys(source)
                .sort()
                .forEach((key) => {
                sortedObj[key] = sortObject(source[key]);
            });
            return sortedObj;
        };
        try {
            return JSON.stringify(sortObject(params));
        }
        catch {
            return '';
        }
    }
}
export const buildListKey = (prefix, params) => {
    return new CacheKeyBuilder(prefix).addList(params).build();
};
export const buildDetailKey = (prefix, id, graphExpr) => {
    const builder = new CacheKeyBuilder(prefix).addId(id);
    if (graphExpr) {
        builder.addGraph(graphExpr);
    }
    return builder.build();
};
export const buildUserCacheKeys = (userId, userUuid, rememberToken, account) => {
    const keys = [];
    const prefix = 'users';
    keys.push(new CacheKeyBuilder(prefix).addId(userId).build());
    keys.push(`${prefix}[id:${userId}]`);
    if (userUuid) {
        keys.push(new CacheKeyBuilder(prefix).addUuid(userUuid).build());
    }
    if (rememberToken) {
        keys.push(new CacheKeyBuilder(prefix).addToken(rememberToken).build());
    }
    if (account) {
        keys.push(new CacheKeyBuilder(prefix).addAccount(account).build());
    }
    return keys;
};
export const buildCachePattern = (prefix, pattern) => {
    return `${prefix}[${pattern}]*`;
};
//# sourceMappingURL=CacheHelper.js.map