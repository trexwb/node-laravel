export function wrapControllerError(controller, method, err) {
    const code = `${controller}.${method}:${err?.code || 'unknown'}`;
    const message = err instanceof Error ? err.message || String(err) : String(err);
    const wrapped = new Error(message);
    wrapped.code = code;
    wrapped.originalError = err;
    return wrapped;
}
export function buildFilters(body, allowedFields) {
    const filters = {};
    for (const field of allowedFields) {
        if (body[field] !== undefined && body[field] !== null && body[field] !== '') {
            filters[field] = body[field];
        }
    }
    return filters;
}
export function getPagination(body, defaults = { page: 1, pageSize: 10 }) {
    const page = Math.max(1, parseInt(String(body.page)) || defaults.page);
    const pageSize = Math.min(100, Math.max(1, parseInt(String(body.pageSize)) || defaults.pageSize));
    return { page, pageSize };
}
//# sourceMappingURL=ControllerHelper.js.map