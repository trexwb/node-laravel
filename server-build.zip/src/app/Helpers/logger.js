import { getTraceId } from './requestContext.js';
import pino from 'pino';
const isDev = (process.env.APP_ENV || process.env.NODE_ENV || 'development') !== 'production';
export const logger = pino({
    level: process.env.LOG_LEVEL || 'info',
    mixin() {
        return {
            traceId: getTraceId(),
            pid: process.pid,
        };
    },
    timestamp: pino.stdTimeFunctions.isoTime,
    serializers: {
        err: pino.stdSerializers.err,
        error: pino.stdSerializers.err,
    },
    transport: isDev
        ? {
            target: 'pino-pretty',
            options: {
                colorize: true,
                translateTime: 'SYS:yyyy-mm-dd HH:MM:ss',
                ignore: 'pid,hostname',
                messageFormat: '[{module}] {msg}',
            },
        }
        : undefined,
});
export function createLogger(module) {
    return logger.child({ module });
}
//# sourceMappingURL=logger.js.map