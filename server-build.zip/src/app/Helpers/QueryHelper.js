export const extractSchemaColumns = (ModelClass) => {
    if (typeof ModelClass.getSchemaDbColumns === 'function') {
        return ModelClass.getSchemaDbColumns();
    }
    const properties = Object.keys(ModelClass.jsonSchema?.properties ?? {});
    const mapper = ModelClass.columnNameMappers;
    if (!mapper?.format) {
        return properties;
    }
    return properties.map((prop) => {
        const mapped = mapper.format({ [prop]: null });
        return Object.keys(mapped)[0];
    });
};
//# sourceMappingURL=QueryHelper.js.map