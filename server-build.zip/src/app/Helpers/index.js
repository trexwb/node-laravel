import { formatDbDateTime } from './format.js';
import dayjs from 'dayjs';
class Utils {
    static titleCase(value) {
        if (value == null || value.length === 0)
            return value;
        return value.replace(/^[a-z]/, (matchStr) => matchStr.toLocaleUpperCase());
    }
    static compressLetter(value, ignoreCase = false) {
        if (typeof value !== 'string')
            return value;
        const pattern = new RegExp('([a-zA-Z])\\1+', ignoreCase ? 'ig' : 'g');
        return value.replace(pattern, (matchStr, group_1) => {
            return matchStr.length + group_1;
        });
    }
    static trim(value) {
        if (typeof value !== 'string')
            return value;
        return value.replace(/(^\s*)|(\s*$)/g, '');
    }
    static trimAll(value) {
        if (typeof value !== 'string')
            return value;
        return value.replace(/\s+/g, '');
    }
    static replaceAll(text, repstr, newstr) {
        if (typeof text !== 'string' || typeof repstr !== 'string' || typeof newstr !== 'string')
            return text;
        return text.replace(new RegExp(repstr, 'gm'), newstr);
    }
    static numberFormatter(num) {
        if (typeof num !== 'string' && typeof num !== 'number')
            return num;
        const strNum = num.toString();
        return strNum.length === 11 ? strNum.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2') : num;
    }
    static moneyFormatter(money) {
        if (typeof money !== 'string' && typeof money !== 'number')
            return String(money);
        const floatMoney = parseFloat(money.toString());
        if (isNaN(floatMoney))
            return '0.00';
        return floatMoney
            .toFixed(2)
            .toString()
            .split('')
            .reverse()
            .join('')
            .replace(/(\d{3})/g, '$1,')
            .replace(/\,$/, '')
            .split('')
            .reverse()
            .join('');
    }
    static dateFormatter(date, format, type = 1, isMs = true) {
        const formatDate = dayjs(date);
        if (formatDate.isValid()) {
            return formatDate.format(format);
        }
        else if (type === 3) {
            return Utils._formatTimeStr(typeof date === 'string' ? date : String(date), format);
        }
        else {
            return Utils._formatDate(format, date, type, isMs);
        }
    }
    static _formatDate(formatStr, fdate, type = 1, isMs) {
        if (!fdate)
            return '';
        let fTime;
        let fStr = 'ymdhis';
        if (type === 4) {
            fTime = fdate;
        }
        else {
            let fdateStr = fdate.toString();
            if (~fdateStr.indexOf('.')) {
                fdateStr = fdateStr.substring(0, fdateStr.indexOf('.'));
            }
            fdateStr = fdateStr.replace('T', ' ').replace(/\-/g, '/');
            if (!formatStr)
                formatStr = 'y-m-d h:i:s';
            if (type === 2 || typeof fdate === 'number') {
                const parsedDate = isMs ? Number(fdateStr) : Number(fdateStr) * 1000;
                fTime = new Date(parsedDate);
            }
            else {
                fTime = new Date(fdateStr);
            }
        }
        const formatArr = [
            fTime.getFullYear().toString(),
            String(fTime.getMonth() + 1).padStart(2, '0'),
            String(fTime.getDate()).padStart(2, '0'),
            String(fTime.getHours()).padStart(2, '0'),
            String(fTime.getMinutes()).padStart(2, '0'),
            String(fTime.getSeconds()).padStart(2, '0'),
        ];
        for (let i = 0; i < formatArr.length; i++) {
            formatStr = formatStr.replace(fStr.charAt(i), formatArr[i]);
        }
        return formatStr;
    }
    static _formatTimeStr(timeStr, formatStr) {
        if (!timeStr || timeStr.length !== 14)
            return timeStr;
        const timeArr = timeStr.split('');
        const formatArr = [
            timeArr.slice(0, 4).join(''),
            timeArr.slice(4, 6).join(''),
            timeArr.slice(6, 8).join(''),
            timeArr.slice(8, 10).join(''),
            timeArr.slice(10, 12).join(''),
            timeArr.slice(12, 14).join(''),
        ];
        const fStr = 'ymdhis';
        if (!formatStr)
            formatStr = 'y-m-d h:i:s';
        for (let i = 0; i < formatArr.length; i++) {
            formatStr = formatStr.replace(fStr.charAt(i), formatArr[i]);
        }
        return formatStr;
    }
    static rgbToHex(r, g, b) {
        return '#' + Utils._toHex(r) + Utils._toHex(g) + Utils._toHex(b);
    }
    static _toHex(n) {
        const num = parseInt(n.toString(), 10);
        if (isNaN(num))
            return '00';
        const clamped = Math.max(0, Math.min(num, 255));
        return '0123456789ABCDEF'.charAt((clamped - (clamped % 16)) / 16) + '0123456789ABCDEF'.charAt(clamped % 16);
    }
    static hexToRGB(hex) {
        if (typeof hex !== 'string' || !/^#?([a-f\d]{3}|[a-f\d]{6})$/i.test(hex))
            return null;
        const normalizedHex = hex.length === 4 ? '#' + hex.substring(1).repeat(2) : hex;
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(normalizedHex);
        return result
            ? {
                r: parseInt(result[1], 16),
                g: parseInt(result[2], 16),
                b: parseInt(result[3], 16),
            }
            : null;
    }
    static unique(n = 6) {
        let rnd = (Math.floor(Math.random() * 9) + 1).toString();
        for (let i = 1; i < n; i++) {
            rnd += Math.floor(Math.random() * 10).toString();
        }
        return rnd;
    }
    static getUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = (Math.random() * 16) | 0;
            const v = c === 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
        });
    }
    static distinctArray(arr1 = [], arr2 = []) {
        return [...new Set([...arr1, ...arr2])];
    }
    static getDateTimeSlot(type) {
        const now = new Date(formatDbDateTime());
        let start;
        let end;
        switch (type) {
            case 1:
                start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
                end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
                break;
            case 2:
                const yesterday = new Date(now);
                yesterday.setDate(yesterday.getDate() - 1);
                start = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 0, 0, 0);
                end = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 23, 59, 59);
                break;
            case 3:
                const weekday = now.getDay() || 7;
                const weekStart = new Date(now);
                weekStart.setDate(weekStart.getDate() - weekday + 1);
                start = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate(), 0, 0, 0);
                end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
                break;
            case 4:
                start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
                end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
                break;
            case 5:
                start = new Date(now.getFullYear(), 0, 1, 0, 0, 0);
                end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
                break;
            default:
                start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
                end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        }
        return { start, end };
    }
    static formatTimeAgo(date, type = 1, isMs = true, suffix = '前', endUnit = 6, seconds = 10, fixedDay = true) {
        const formatDate = Utils.dateFormatter(date, 'y/m/d h:i:s', type, isMs);
        const beforeStamp = new Date(formatDbDateTime(formatDate)).getTime();
        const nowStamp = new Date(formatDbDateTime()).getTime();
        let res = '';
        const diff = nowStamp - beforeStamp;
        if (diff > 0) {
            const _minute = 1000 * 60;
            const _hour = _minute * 60;
            const _day = _hour * 24;
            const _month = _day * 30;
            const _year = _month * 12;
            const year = Math.floor(diff / _year);
            const month = Math.floor(diff / _month);
            const day = Math.floor(diff / _day);
            const hour = Math.floor(diff / _hour);
            const minute = Math.floor(diff / _minute);
            const second = Math.floor(diff / 1000);
            let isEmpty = false;
            switch (endUnit) {
                case 1:
                    isEmpty = minute || hour || day || month || year ? true : false;
                    break;
                case 2:
                    isEmpty = hour || day || month || year ? true : false;
                    break;
                case 3:
                    isEmpty = day || month || year ? true : false;
                    break;
                case 4:
                    isEmpty = month || year ? true : false;
                    break;
                case 5:
                    isEmpty = year ? true : false;
                    break;
                default:
                    break;
            }
            if (!isEmpty) {
                if (year) {
                    res = `${year}年${suffix}`;
                }
                else if (month) {
                    res = `${month}个月${suffix}`;
                }
                else if (day) {
                    if (day === 1 && fixedDay) {
                        res = '昨天';
                    }
                    else if (day === 2 && fixedDay) {
                        res = '前天';
                    }
                    else {
                        res = `${day}天${suffix}`;
                    }
                }
                else if (hour) {
                    res = `${hour}小时${suffix}`;
                }
                else if (minute) {
                    res = `${minute}分钟${suffix}`;
                }
                else {
                    const sec = seconds < 60 ? seconds : 59;
                    res = second < sec ? '刚刚' : `${second}秒${suffix}`;
                }
            }
        }
        return res;
    }
    static empty(value) {
        if (value === null || value === undefined)
            return true;
        if (typeof value === 'string' && Utils.trim(value) === '')
            return true;
        if (Array.isArray(value) && value.length === 0)
            return true;
        if (typeof value === 'object' && Object.keys(value).length === 0)
            return true;
        return false;
    }
    static generateRandomString(length) {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        return Array.from({ length }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join('');
    }
    static safeJSONStringify(value) {
        try {
            return JSON.stringify(value);
        }
        catch (error) {
            return null;
        }
    }
    static safeCastToInteger(value) {
        if (typeof value === 'number' && !isNaN(value))
            return Math.max(0, Number(value));
        if (typeof value === 'string' && value.trim() !== '') {
            const parsed = parseFloat(value);
            return isNaN(parsed) ? 0 : Math.max(0, Number(parsed));
        }
        return 0;
    }
    static normalizeSort(sort, allowedColumns) {
        if (!sort)
            return undefined;
        const match = sort.match(/^([+-])(.*?)$/);
        if (!match)
            return undefined;
        const column = match[2];
        if (!allowedColumns.includes(column))
            return undefined;
        return {
            column,
            order: match[1] === '-' ? 'DESC' : 'ASC',
        };
    }
    static sortMultiDimensionalObject(obj) {
        if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
            const sortedObject = {};
            const keys = Object.keys(obj).sort();
            for (const key of keys) {
                sortedObject[key] = Utils.sortMultiDimensionalObject(obj[key]);
            }
            return Object.keys(obj).length > 0 ? sortedObject : null;
        }
        else if (Array.isArray(obj)) {
            return obj.length > 0 ? obj.sort().map((item) => Utils.sortMultiDimensionalObject(item)) : null;
        }
        else {
            return obj || null;
        }
    }
    static isValidCronFormatFlexible(rowTime) {
        const cronPatternWithSeconds = /^([0-5]?\d|\*|(?:\*\/[1-9][0-9]?))\s([0-5]?\d|\*|(?:\*\/[1-9][0-9]?))\s([01]?\d|2[0-3]|\*|(?:\*\/[1-9][0-9]?))\s([1-9]|1\d|2[0-9]|3[01]|\*)\s(1[0-2]|0?[1-9]|\*)\s([0-6]|\*)$/;
        const cronPatternWithoutSeconds = /^([0-5]?\d|\*|(?:\*\/[1-9][0-9]?))\s([01]?\d|2[0-3]|\*|(?:\*\/[1-9][0-9]?))\s([1-9]|1\d|2[0-9]|3[01]|\*)\s(1[0-2]|0?[1-9]|\*)\s([0-6]|\*)$/;
        return cronPatternWithSeconds.test(rowTime) || cronPatternWithoutSeconds.test(rowTime);
    }
    static generateFormattedSerial(groupSize = 5, numberOfGroups = 4) {
        const possibleChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const totalLength = (groupSize || 5) * (numberOfGroups || 4);
        const randomPart = Array.from({ length: totalLength }, () => possibleChars.charAt(Math.floor(Math.random() * possibleChars.length))).join('');
        return 'SN-' + randomPart.match(new RegExp('.{1,' + groupSize + '}', 'g')).join('-');
    }
    static splitCamelCase(str) {
        return str.replace(/([a-z])([A-Z])/g, '$1 $2').split(' ');
    }
    static toCamelCase(arr) {
        return arr
            .map((word, index) => {
            if (index === 0) {
                return word.toLowerCase();
            }
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        })
            .join('');
    }
    static filterEmpty(obj) {
        const result = {};
        for (const [key, value] of Object.entries(obj)) {
            if (value === null || value === undefined || value === '')
                continue;
            if (typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date)) {
                const cleaned = Utils.filterEmpty(value);
                if (Object.keys(cleaned).length > 0) {
                    result[key] = cleaned;
                }
                continue;
            }
            result[key] = value;
        }
        return result;
    }
    static parseFilter(input) {
        if (input === null || input === undefined) {
            return {};
        }
        if (typeof input === 'string') {
            const trimmed = input.trim();
            if (trimmed === '') {
                return {};
            }
            try {
                const parsed = JSON.parse(trimmed);
                if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
                    return {};
                }
                return Utils.filterEmpty(parsed);
            }
            catch {
                return {};
            }
        }
        if (typeof input === 'object' && !Array.isArray(input) && !(input instanceof Date)) {
            return Utils.filterEmpty(input);
        }
        return {};
    }
}
export default Utils;
//# sourceMappingURL=index.js.map