export const normalizePagination = (page, pageSize) => {
    const safePage = toSafeInteger(page ?? 1);
    const safePageSize = toSafeInteger(pageSize ?? 10);
    return {
        page: Math.max(1, safePage),
        pageSize: Math.max(1, Math.min(safePageSize, 100)),
    };
};
export const toSafeInteger = (value) => {
    if (typeof value === 'number' && !isNaN(value)) {
        return Number.isInteger(value) ? value : Math.floor(value);
    }
    if (typeof value === 'string' && value.trim() !== '') {
        const parsed = parseFloat(value);
        return isNaN(parsed) ? 0 : Math.floor(parsed);
    }
    return 0;
};
export const sortForCacheKey = (params) => {
    if (!params)
        return '';
    if (Array.isArray(params)) {
        return JSON.stringify(params.map((item) => (typeof item === 'object' && item !== null ? sortObjectKeys(item) : item)));
    }
    return JSON.stringify(sortObjectKeys(params));
};
const sortObjectKeys = (obj) => {
    const sortedObj = {};
    const keys = Object.keys(obj).sort();
    for (const key of keys) {
        const value = obj[key];
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            sortedObj[key] = sortObjectKeys(value);
        }
        else if (Array.isArray(value)) {
            sortedObj[key] = value.map((item) => typeof item === 'object' && item !== null ? sortObjectKeys(item) : item);
        }
        else {
            sortedObj[key] = value;
        }
    }
    return sortedObj;
};
export const buildListCacheKey = (cacheKeyPrefix, filters, pagination, sort, trashed = false, graphExpr) => {
    const baseParams = [filters, pagination.page, pagination.pageSize, sort, trashed];
    if (graphExpr) {
        baseParams.push(graphExpr);
    }
    const sortedParams = sortForCacheKey(baseParams);
    const queryType = graphExpr ? 'list_graph' : 'list';
    return `${cacheKeyPrefix}[${queryType}:${sortedParams}]`;
};
export const buildDetailCacheKey = (cacheKeyPrefix, id, graphExpr, trashed = false) => {
    if (graphExpr) {
        return `${cacheKeyPrefix}[id:${id}][graph:${graphExpr}][trashed:${trashed ? 1 : 0}]`;
    }
    return `${cacheKeyPrefix}[id:${id}]`;
};
//# sourceMappingURL=query.js.map