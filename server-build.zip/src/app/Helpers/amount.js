export function isValidMoneyString(value) {
    return /^\d+(\.\d{1,2})?$/.test(String(value ?? '').trim());
}
//# sourceMappingURL=amount.js.map