function arrayToGraph(rels) {
    if (!rels.length)
        return '';
    const simple = [];
    const nested = [];
    for (const rel of rels) {
        if (!rel)
            continue;
        if (!rel.includes('.')) {
            simple.push(rel);
        }
        else {
            const parts = rel.split('.');
            const prefix = parts[0];
            const suffix = parts.slice(1).join('.');
            const existing = nested.find((n) => n.prefix === prefix);
            if (existing) {
                if (!existing.suffixes.includes(suffix)) {
                    existing.suffixes.push(suffix);
                }
            }
            else {
                nested.push({ prefix, suffixes: [suffix] });
            }
        }
    }
    const parts = [];
    parts.push(...simple);
    for (const n of nested) {
        if (n.suffixes.length === 1) {
            parts.push(`${n.prefix}.${n.suffixes[0]}`);
        }
        else {
            parts.push(`${n.prefix}.[${n.suffixes.join(',')}]`);
        }
    }
    return `[${parts.join(',')}]`;
}
export function normalizeGraph(graph) {
    if (!graph)
        return undefined;
    if (Array.isArray(graph)) {
        const rels = graph.map((s) => String(s || '').trim()).filter(Boolean);
        if (!rels.length)
            return undefined;
        return arrayToGraph(rels);
    }
    const g = String(graph).trim();
    return g.length ? g : undefined;
}
export function wrapServiceError(service, action, err) {
    if (err && typeof err === 'object') {
        if (!err.code)
            err.code = `${service}.${action}`;
        return err;
    }
    const e = new Error(typeof err === 'string' ? err : 'Service error');
    e.code = `${service}.${action}`;
    return e;
}
export async function findOneWithGraph(ModelClass, params) {
    const { filters, trashed = false, graph, graphOptions } = params;
    const graphExpr = normalizeGraph(graph);
    let query = ModelClass.buildQuery(ModelClass.query(), filters, trashed);
    if (graphExpr)
        query = query.withGraphFetched(graphExpr, graphOptions);
    return await query.first();
}
export async function findManyWithGraph(ModelClass, params) {
    const { filters, page, pageSize, order, trashed = false, graph, graphOptions } = params;
    const graphExpr = normalizeGraph(graph);
    const offset = (page - 1) * pageSize;
    const baseQuery = ModelClass.buildQuery(ModelClass.query(), filters, trashed);
    const total = await baseQuery.clone().resultSize();
    let dataQuery = baseQuery.clone();
    if (order) {
        ModelClass.applyOrder(dataQuery, order);
    }
    if (graphExpr)
        dataQuery = dataQuery.withGraphFetched(graphExpr, graphOptions);
    const data = await dataQuery.limit(pageSize).offset(offset);
    return {
        data,
        meta: {
            total,
            page,
            pageSize,
            totalPages: Math.ceil(total / pageSize),
        },
    };
}
export async function findAllWithGraph(ModelClass, params) {
    const { filters, order, trashed = false, graph, graphOptions } = params;
    const graphExpr = normalizeGraph(graph);
    let query = ModelClass.buildQuery(ModelClass.query(), filters, trashed);
    if (order) {
        ModelClass.applyOrder(query, order);
    }
    if (graphExpr)
        query = query.withGraphFetched(graphExpr, graphOptions);
    return await query;
}
//# sourceMappingURL=OrmGraphHelper.js.map