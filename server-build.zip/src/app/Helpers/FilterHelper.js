export function buildFilter(req, extra, overrides) {
    const body = req.body ?? {};
    let base;
    if (body.filter && typeof body.filter === 'object') {
        base = { ...body.filter };
    }
    else if (body.id !== undefined) {
        base = { id: body.id };
    }
    else {
        base = {};
    }
    if (overrides) {
        for (const [srcField, dstField] of Object.entries(overrides)) {
            if (body[srcField] !== undefined) {
                if (dstField === 'id' && base.id === undefined) {
                    base.id = body[srcField];
                }
                else {
                    base[dstField] = body[srcField];
                }
            }
        }
    }
    if (extra) {
        Object.assign(base, extra);
    }
    return base;
}
export function buildIdFilter(req, paramName = 'id') {
    const id = req.params[paramName] ?? req.body.id ?? req.query.id;
    return { id: Number(id) };
}
//# sourceMappingURL=FilterHelper.js.map