export function filterTreeNodeFields(node, fields, childrenKey = 'children') {
    if (Array.isArray(node)) {
        return node.map((item) => filterTreeNodeFieldsSingle(item, fields, childrenKey));
    }
    return filterTreeNodeFieldsSingle(node, fields, childrenKey);
}
function filterTreeNodeFieldsSingle(node, fields, childrenKey) {
    const result = {};
    for (const field of fields) {
        if (field in node) {
            result[field] = node[field];
        }
    }
    const children = node[childrenKey];
    if (childrenKey in node && Array.isArray(children) && children.length > 0) {
        result[childrenKey] = children.map((child) => filterTreeNodeFieldsSingle(child, fields, childrenKey));
    }
    return result;
}
export function filterFlatFields(list, fields) {
    return list.map((item) => {
        const result = {};
        for (const field of fields) {
            if (field in item) {
                result[field] = item[field];
            }
        }
        return result;
    });
}
export function filterCategoryTreeFields(tree) {
    const CATEGORY_FIELDS = ['id', 'names', 'abbreviation', 'covers', 'remarks', 'total', 'sort', 'children'];
    return filterTreeNodeFields(tree, CATEGORY_FIELDS);
}
//# sourceMappingURL=TransformerHelper.js.map