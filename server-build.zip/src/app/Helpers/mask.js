export function maskPhone(phone) {
    if (!phone)
        return null;
    const s = String(phone).trim();
    if (!/^\d{11}$/.test(s))
        return s;
    return s.substring(0, 3) + '****' + s.substring(7);
}
//# sourceMappingURL=mask.js.map