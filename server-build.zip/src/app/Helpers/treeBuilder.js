export function buildTree(list, options = {}) {
    const { idKey = 'id', parentKey = 'parentId', sortKey = 'sort', rootValue = null, childrenKey = 'children' } = options;
    const map = new Map();
    for (const item of list) {
        const row = item;
        map.set(row[idKey], { ...item, [childrenKey]: [] });
    }
    const roots = [];
    for (const item of list) {
        const row = item;
        const node = map.get(row[idKey]);
        const pid = row[parentKey];
        if (pid === rootValue || pid === undefined || pid === null) {
            roots.push(node);
        }
        else {
            const parent = map.get(pid);
            if (parent) {
                const children = parent[childrenKey];
                children.push(node);
            }
            else {
                roots.push(node);
            }
        }
    }
    const sortNodes = (nodes) => {
        nodes.sort((a, b) => {
            const aRow = a;
            const bRow = b;
            return Number(aRow[sortKey] ?? 0) - Number(bRow[sortKey] ?? 0);
        });
        for (const node of nodes) {
            const children = node[childrenKey];
            if (children && children.length > 0) {
                sortNodes(children);
            }
        }
    };
    sortNodes(roots);
    return roots;
}
export function flattenTree(tree, childrenKey = 'children') {
    const result = [];
    const stack = [...tree];
    while (stack.length > 0) {
        const node = stack.shift();
        const { [childrenKey]: children, ...rest } = node;
        result.push(rest);
        if (Array.isArray(children) && children.length > 0) {
            stack.unshift(...children);
        }
    }
    return result;
}
export function getAncestorIds(id, flatList, idKey = 'id', parentKey = 'parentId') {
    const map = new Map();
    for (const item of flatList) {
        map.set(item[idKey], item);
    }
    const ancestors = [];
    let current = map.get(id);
    while (current !== undefined && current !== null) {
        const pid = current[parentKey];
        if (pid === null || pid === undefined)
            break;
        ancestors.unshift(pid);
        current = map.get(pid);
    }
    return ancestors;
}
export function getDescendantIds(id, flatList, idKey = 'id', parentKey = 'parentId') {
    const result = [id];
    const queue = [id];
    while (queue.length > 0) {
        const pid = queue.shift();
        for (const item of flatList) {
            if (item[parentKey] === pid) {
                result.push(item[idKey]);
                queue.push(item[idKey]);
            }
        }
    }
    return result;
}
//# sourceMappingURL=treeBuilder.js.map