import crypto from 'node:crypto';
const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEY_LEN = 64;
const PREFIX = 'scrypt$';
export function makePassword(plain) {
    const salt = crypto.randomBytes(16).toString('hex');
    const derived = crypto.scryptSync(plain, salt, KEY_LEN, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P });
    return {
        password: `${PREFIX}${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt}$${derived.toString('base64')}`,
        salt: crypto.randomBytes(3).toString('hex'),
    };
}
export function verifyPassword(plain, storedPassword, legacySalt) {
    if (!storedPassword)
        return { valid: false, upgrade: false };
    if (storedPassword.startsWith(PREFIX)) {
        try {
            const parts = storedPassword.slice(PREFIX.length).split('$');
            if (parts.length !== 5)
                return { valid: false, upgrade: false };
            const [nStr, rStr, pStr, salt, hashB64] = parts;
            const n = Number(nStr);
            const r = Number(rStr);
            const p = Number(pStr);
            if (!n || !r || !p || !salt || !hashB64)
                return { valid: false, upgrade: false };
            const derived = crypto.scryptSync(plain, salt, KEY_LEN, { N: n, r, p });
            const expected = Buffer.from(hashB64, 'base64');
            const valid = derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
            console.log('valid', valid);
            return { valid, upgrade: false };
        }
        catch {
            return { valid: false, upgrade: false };
        }
    }
    const legacy = crypto
        .createHash('md5')
        .update(plain + (legacySalt || ''))
        .digest('hex');
    const valid = legacy === storedPassword;
    return { valid, upgrade: valid };
}
//# sourceMappingURL=hashPassword.js.map