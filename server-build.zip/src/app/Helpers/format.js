import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone.js';
import utc from 'dayjs/plugin/utc.js';
dayjs.extend(utc);
dayjs.extend(timezone);
export const DEFAULT_TIME_ZONE = 'Asia/Shanghai';
dayjs.tz.setDefault(DEFAULT_TIME_ZONE);
export const getAppTimezone = () => DEFAULT_TIME_ZONE;
export const now = () => {
    try {
        return dayjs().tz(DEFAULT_TIME_ZONE);
    }
    catch {
        return dayjs();
    }
};
export const nowDate = () => {
    try {
        return dayjs().tz(DEFAULT_TIME_ZONE).toDate();
    }
    catch {
        return new Date();
    }
};
function safeTz(d, tz = DEFAULT_TIME_ZONE) {
    if (!d.isValid())
        return d;
    try {
        return d.tz(tz);
    }
    catch {
        return d;
    }
}
function safeTzParse(raw, tz = DEFAULT_TIME_ZONE) {
    try {
        return dayjs.tz(raw, tz);
    }
    catch {
        return dayjs(NaN);
    }
}
function safeFormat(d, formatString) {
    try {
        return d.isValid() ? d.format(formatString) : fallback(formatString);
    }
    catch {
        return fallback(formatString);
    }
}
function fallback(formatString) {
    try {
        return dayjs().tz(DEFAULT_TIME_ZONE).format(formatString);
    }
    catch {
        return dayjs().format(formatString);
    }
}
export const formatDate = (input = null, formatString = 'YYYY-MM-DD HH:mm:ss') => {
    if (!input)
        return fallback(formatString);
    if (input instanceof Date) {
        if (isNaN(input.getTime()))
            return fallback(formatString);
        return safeFormat(safeTz(dayjs(input)), formatString);
    }
    if (typeof input === 'number') {
        if (!Number.isFinite(input))
            return fallback(formatString);
        return safeFormat(safeTz(dayjs(input)), formatString);
    }
    const raw = String(input).trim();
    if (!raw)
        return fallback(formatString);
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
        return safeFormat(safeTzParse(raw), formatString);
    }
    if (raw.endsWith('Z') || /^\d{4}-\d{2}-\d{2}T/.test(raw) || /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[+\-]\d{2}:?\d{2}$/.test(raw)) {
        return safeFormat(safeTz(dayjs.utc(raw)), formatString);
    }
    return safeFormat(safeTzParse(raw), formatString);
};
export const formatDbDateTime = (input = null) => {
    return formatDate(input, 'YYYY-MM-DD HH:mm:ss');
};
export const formatDbDateTimeFromUTC = (input = null) => {
    return formatDateFromUTC(input, 'YYYY-MM-DD HH:mm:ss');
};
export const formatDateFromUTC = (input = null, formatString = 'YYYY-MM-DD HH:mm:ss') => {
    if (!input)
        return fallback(formatString);
    if (input instanceof Date) {
        if (isNaN(input.getTime()))
            return fallback(formatString);
        return safeFormat(safeTz(dayjs.utc(input)), formatString);
    }
    if (typeof input === 'number') {
        if (!Number.isFinite(input))
            return fallback(formatString);
        return safeFormat(safeTz(dayjs.utc(input)), formatString);
    }
    const raw = String(input).trim();
    if (!raw)
        return fallback(formatString);
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
        return raw;
    }
    if (raw.endsWith('Z') || /^[+\-]?\d/.test(raw)) {
        return safeFormat(safeTz(dayjs.utc(raw)), formatString);
    }
    return safeFormat(safeTzParse(raw), formatString);
};
export const formatAsIs = (input = null, formatString = 'YYYY-MM-DD HH:mm:ss') => {
    if (!input)
        return dayjs().format(formatString);
    if (input instanceof Date) {
        if (isNaN(input.getTime()))
            return dayjs().format(formatString);
        return dayjs(input).format(formatString);
    }
    if (typeof input === 'number') {
        return dayjs(input).format(formatString);
    }
    const raw = String(input).trim();
    if (!raw)
        return dayjs().format(formatString);
    if (raw.endsWith('Z') || /^[+\-]?\d/.test(raw)) {
        return dayjs.utc(raw).format(formatString);
    }
    return dayjs(raw).format(formatString);
};
export const addSecondsDbDateTime = (seconds, base = null, formatString = 'YYYY-MM-DD HH:mm:ss') => {
    const sec = Number.isFinite(Number(seconds)) ? Number(seconds) : 0;
    let baseTime;
    if (!base) {
        baseTime = now();
    }
    else if (base instanceof Date) {
        baseTime = isNaN(base.getTime()) ? now() : safeTz(dayjs(base));
    }
    else if (typeof base === 'number') {
        if (!Number.isFinite(base)) {
            baseTime = now();
        }
        else {
            baseTime = safeTz(dayjs(base));
        }
    }
    else {
        const raw = String(base).trim();
        if (!raw) {
            baseTime = now();
        }
        else if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
            baseTime = safeTzParse(raw);
        }
        else if (raw.endsWith('Z') || /^[+\-]?\d/.test(raw)) {
            baseTime = safeTz(dayjs.utc(raw));
        }
        else {
            baseTime = safeTzParse(raw);
        }
    }
    return baseTime.add(sec, 'second').format(formatString);
};
export const parseDbDateTime = (input = null) => {
    if (!input)
        return nowDate();
    if (input instanceof Date) {
        return isNaN(input.getTime()) ? nowDate() : input;
    }
    if (typeof input === 'number')
        return new Date(input);
    const raw = String(input).trim();
    if (!raw)
        return nowDate();
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
        const parsed = safeTzParse(raw);
        return parsed.isValid() ? parsed.utc().toDate() : nowDate();
    }
    if (raw.endsWith('Z') || /^[+\-]?\d/.test(raw)) {
        const parsed = safeTz(dayjs.utc(raw));
        return parsed.isValid() ? parsed.toDate() : nowDate();
    }
    const parsed = safeTzParse(raw);
    return parsed.isValid() ? parsed.toDate() : nowDate();
};
export const formatCurrency = (amount) => {
    return new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(amount);
};
export const utcToLocal = (input = null) => {
    if (!input)
        return nowDate();
    return safeTz(dayjs.utc(input)).toDate();
};
export const localToUtc = (input = null) => {
    if (!input)
        return new Date();
    return safeTz(dayjs(input)).utc().toDate();
};
export const getTimezone = () => DEFAULT_TIME_ZONE;
export default dayjs;
//# sourceMappingURL=format.js.map