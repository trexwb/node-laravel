export class CastJson {
    get(value) {
        if (typeof value === 'string') {
            try {
                return JSON.parse(value);
            }
            catch {
                return {};
            }
        }
        return value || {};
    }
    set(value) {
        return typeof value === 'string' ? value : JSON.stringify(value);
    }
}
//# sourceMappingURL=CastJsonCasts.js.map