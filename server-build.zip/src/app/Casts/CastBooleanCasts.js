export class CastBoolean {
    get(value) {
        return Boolean(value);
    }
    set(value) {
        return value ? 1 : 0;
    }
}
//# sourceMappingURL=CastBooleanCasts.js.map