import dayjs from '../Helpers/format.js';
export class CastDateTime {
    options;
    constructor(options = {}) {
        this.options = options;
    }
    get(value) {
        if (!value)
            return null;
        const tz = this.options.timezone;
        const date = tz ? dayjs.tz(value, tz) : dayjs(value);
        return this.options.format ? date.format(this.options.format) : date;
    }
    set(value) {
        if (!value)
            return null;
        const date = dayjs(value);
        if (this.options.storeAsUtc !== false) {
            return date.utc().format('YYYY-MM-DD HH:mm:ss');
        }
        return date.format('YYYY-MM-DD HH:mm:ss');
    }
}
//# sourceMappingURL=CastDateTimeCasts.js.map