import Validator from 'validatorjs';
Validator.register('nullable', () => true);
Validator.register('object', () => true);
Validator.register('optional', () => true);
Validator.registerAsync('unique', async (value, args, _attribute, passes) => {
    const [argPart, modelClassName] = args.split('::');
    const [column, exceptId] = argPart.split(',');
    if (!modelClassName) {
        passes(false, 'unique 规则缺少 ModelClass 参数（格式：unique:col,id::ModelClass）');
        return;
    }
    const dbColumn = column.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);
    const ModelClass = globalThis[modelClassName];
    if (!ModelClass || typeof ModelClass.query !== 'function') {
        passes(false, `Model "${modelClassName}" not found`);
        return;
    }
    let query = ModelClass.query().where(dbColumn, value);
    if (exceptId && Number(exceptId) > 0) {
        query = query.whereNot('id', exceptId);
    }
    const exists = await query.first();
    exists ? passes(false) : passes();
}, '该值已存在');
Validator.registerAsync('uniqueComposite', async (value, args, _attribute, passes) => {
    const [argPart, modelClassName] = args.split('::');
    const [enumType, exceptId] = argPart.split(',');
    if (!modelClassName) {
        passes(false, 'uniqueComposite 规则缺少 ModelClass 参数（格式：uniqueComposite:col,id::ModelClass）');
        return;
    }
    const ModelClass = globalThis[modelClassName];
    if (!ModelClass || typeof ModelClass.query !== 'function') {
        passes(false, `Model "${modelClassName}" not found`);
        return;
    }
    const dbEnumType = enumType.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);
    let query = ModelClass.query().where('enum_type', dbEnumType).where('enum_key', value);
    if (exceptId && Number(exceptId) > 0) {
        query = query.whereNot('id', exceptId);
    }
    const exists = await query.first();
    exists ? passes(false) : passes();
}, '该枚举类型下已存在相同的键名');
export class BaseRequest {
    req;
    constructor(req) {
        this.req = req;
    }
    messages() {
        return {};
    }
    authorize() {
        return true;
    }
    prepareForValidation() {
        this.parseJsonFields(this.req.body);
    }
    parseJsonFields(obj, depth = 0) {
        if (depth > 10)
            return;
        if (!obj || typeof obj !== 'object')
            return;
        for (const key of Object.keys(obj)) {
            const val = obj[key];
            if (typeof val === 'string') {
                const trimmed = val.trim();
                if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
                    try {
                        obj[key] = JSON.parse(trimmed);
                    }
                    catch {
                    }
                }
            }
            else if (typeof val === 'object' && val !== null) {
                this.parseJsonFields(val, depth + 1);
            }
        }
    }
    expandWildcardRules(data, rules) {
        const allErrors = {};
        for (const ruleKey of Object.keys(rules)) {
            if (!ruleKey.includes('.*.'))
                continue;
            const parts = ruleKey.split('.');
            const arrayKey = parts[0];
            const fieldKey = parts[2];
            const arrayValue = data[arrayKey];
            if (!Array.isArray(arrayValue))
                continue;
            for (let idx = 0; idx < arrayValue.length; idx++) {
                const item = arrayValue[idx];
                if (item == null)
                    continue;
                const itemValidator = new Validator({ [fieldKey]: item[fieldKey] }, { [fieldKey]: rules[ruleKey] });
                itemValidator.passes();
                const itemErrors = itemValidator.errors.all();
                if (Object.keys(itemErrors).length > 0) {
                    const attr = `${arrayKey}[${idx}].${fieldKey}`;
                    if (!allErrors[attr])
                        allErrors[attr] = [];
                    for (const msgs of Object.values(itemErrors)) {
                        allErrors[attr].push(...msgs);
                    }
                }
            }
        }
        return allErrors;
    }
    collectValidatedKeys(rules) {
        const keys = new Set();
        for (const key of Object.keys(rules)) {
            keys.add(key);
            const dotIdx = key.indexOf('.');
            if (dotIdx > 0) {
                const parent = key.slice(0, dotIdx);
                if (!keys.has(parent))
                    keys.add(parent);
            }
        }
        return Array.from(keys);
    }
    all() {
        return this.req.body;
    }
    input(key, defaultValue) {
        return this.req.body?.[key] ?? defaultValue;
    }
    async validate() {
        if (!this.authorize()) {
            throw new Error('无权操作');
        }
        this.prepareForValidation();
        const data = this.all();
        const rules = this.rules();
        const wildcardErrors = this.expandWildcardRules(data, rules);
        const validator = new Validator(data, rules, this.messages());
        await this.registerAsyncRules();
        await new Promise((resolve, reject) => {
            validator.checkAsync(() => resolve(), () => reject({ ...validator.errors.all(), ...wildcardErrors }));
        });
        const validated = {};
        for (const key of this.collectValidatedKeys(rules)) {
            if (key in data) {
                validated[key] = this.castValue(data[key], rules[key]);
            }
        }
        return validated;
    }
    castValue(value, rule) {
        if (value === undefined || value === null)
            return value;
        const rules = rule.split('|');
        if (rules.includes('integer'))
            return Number(value);
        if (rules.includes('numeric'))
            return Number(value);
        if (rules.includes('boolean'))
            return Boolean(value);
        if (rules.includes('string'))
            return String(value);
        return value;
    }
    async registerAsyncRules() { }
}
//# sourceMappingURL=BaseRequest.js.map