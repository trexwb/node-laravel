import crypto from 'node:crypto';
import { config } from '../../../bootstrap/configLoader.js';
import { CacheService } from '../../Services/Cache/CacheService.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
export const refreshToken = async (req, res, next) => {
    const tokenTime = config('app.security.token_time');
    const currentUser = req.currentUser;
    const currentTokenPayload = req.tokenPayload;
    let shouldRefresh = false;
    if (currentUser && currentTokenPayload && currentTokenPayload.timeStamp) {
        const now = Math.floor(Date.now() / 1000);
        const timeLeft = currentTokenPayload.timeStamp - now;
        if (timeLeft > 0 && timeLeft < tokenTime / 2) {
            shouldRefresh = true;
            const oldJti = currentTokenPayload.jti;
            if (typeof oldJti === 'string' && oldJti.length > 0) {
                try {
                    await CacheService.set(`token:blacklist:${oldJti}`, '1', Math.max(Math.floor(timeLeft), 1));
                }
                catch (cacheErr) {
                    console.warn('[RefreshToken] Failed to revoke old token:', cacheErr);
                }
            }
        }
    }
    const originalJson = res.json;
    res.json = function (body) {
        if (shouldRefresh && currentUser && currentTokenPayload?.timeStamp) {
            const now = Math.floor(Date.now() / 1000);
            const newTokenData = {
                token: currentUser.rememberToken,
                timeStamp: now + tokenTime,
                jti: crypto.randomUUID(),
            };
            const newToken = CryptoTool.generateToken(JSON.stringify(newTokenData));
            if (newToken !== undefined && newToken !== null) {
                res.setHeader('X-New-Token', newToken);
                res.setHeader('Access-Control-Expose-Headers', 'X-New-Token');
            }
        }
        return originalJson.call(this, body);
    };
    next();
};
//# sourceMappingURL=RefreshToken.js.map