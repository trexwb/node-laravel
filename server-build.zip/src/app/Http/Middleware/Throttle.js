import rateLimit from 'express-rate-limit';
export const throttle = (max = 60, windowMinutes = 1) => {
    return rateLimit({
        windowMs: windowMinutes * 60 * 1000,
        max: max,
        standardHeaders: true,
        legacyHeaders: false,
        validate: { trustProxy: false },
        handler: (_req, res) => {
            res.status(429).json({
                message: 'Too Many Attempts.',
                retry_after: `${windowMinutes} minute(s)`,
            });
        },
    });
};
//# sourceMappingURL=Throttle.js.map