import { formatDateFromUTC } from '../../Helpers/format.js';
function normalizeResponseDates(value) {
    if (value === null || value === undefined)
        return value;
    if (value instanceof Date) {
        return formatDateFromUTC(value);
    }
    if (Array.isArray(value)) {
        return value.map((item) => normalizeResponseDates(item));
    }
    if (typeof value === 'string') {
        const raw = value.trim();
        if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(raw) ||
            /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(raw) ||
            /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[+\-]\d{2}:?\d{2}$/.test(raw)) {
            return formatDateFromUTC(raw);
        }
        return value;
    }
    if (typeof value === 'object') {
        const result = {};
        for (const [key, item] of Object.entries(value)) {
            result[key] = normalizeResponseDates(item);
        }
        return result;
    }
    return value;
}
export const responseWrapper = (_req, res, next) => {
    res.success = function (data = null, codeOrMsg, msg) {
        let code = 200;
        let message = 'success';
        if (typeof codeOrMsg === 'string') {
            message = codeOrMsg;
        }
        else if (typeof codeOrMsg === 'number') {
            code = codeOrMsg;
            message = msg || 'success';
        }
        const dataObj = { code, msg: message };
        if (data)
            dataObj.data = normalizeResponseDates(data);
        const statusCode = Number((code || 400).toString().substring(0, 3)) || 200;
        return res.status(statusCode).json(dataObj);
    };
    res.error = function (code = 400, msg = 'fail') {
        const dataObj = {
            code,
            msg,
        };
        return res.status(Number((code || 400).toString().substring(0, 3) || 400)).json(dataObj);
    };
    next();
};
//# sourceMappingURL=ResponseWrapper.js.map