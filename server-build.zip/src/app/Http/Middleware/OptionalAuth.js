import { authenticateToken } from './AuthenticateToken.js';
export const optionalAuth = async (req, res, next) => {
    const authHeader = req.headers?.authorization;
    if (!authHeader || !String(authHeader).startsWith('Bearer ')) {
        next();
        return;
    }
    return authenticateToken(req, res, next);
};
//# sourceMappingURL=OptionalAuth.js.map