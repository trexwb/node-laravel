import { requestContext } from '../../Helpers/requestContext.js';
import { randomUUID } from 'node:crypto';
export function traceIdMiddleware(req, res, next) {
    const traceId = req.headers['x-trace-id'] || randomUUID();
    res.setHeader('x-trace-id', traceId);
    requestContext.run({
        traceId,
        pid: process.pid,
        path: req.path,
        method: req.method,
    }, next);
}
//# sourceMappingURL=TraceId.js.map