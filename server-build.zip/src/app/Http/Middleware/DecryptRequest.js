import { config } from '../../../bootstrap/configLoader.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
import { createLogger } from '../../Helpers/logger.js';
const log = createLogger('Middleware:Decrypt');
export const decryptRequest = (req, res, next) => {
    const isEnabled = config('app.security.request_encrypt');
    if (!isEnabled || req.method === 'GET')
        return next();
    if (!req.body) {
        return next();
    }
    const encryptedData = req.body.encryptedData;
    if (!encryptedData || typeof encryptedData !== 'string') {
        if (config('app.debugger')) {
            log.debug({
                path: req.path,
                hasEncryptedData: !!encryptedData,
                encryptedDataType: typeof encryptedData,
                bodyKeys: Object.keys(req.body),
            }, 'Skip decryption - no encryptedData found');
        }
        return next();
    }
    try {
        const appKey = req.secretRow?.appSecret || config('app.security.app_key');
        if (config('app.debugger')) {
            log.debug({
                path: req.path,
                encryptedLength: encryptedData.length,
                encryptedPreview: encryptedData.substring(0, 50),
                hasCustomKey: !!req.secretRow?.appSecret,
                hasCustomIv: !!req.secretRow?.appIv,
            }, 'Attempting decryption');
        }
        const decryptData = CryptoTool.decrypt(encryptedData, appKey);
        if (!decryptData) {
            log.warn({
                path: req.path,
                encryptedPreview: encryptedData.substring(0, 50),
            }, 'Decryption returned empty result');
            return res.error(400019004001, 'Data decryption failed. Invalid format or key.');
        }
        if (config('app.debugger')) {
            log.debug({
                path: req.path,
                decryptedType: typeof decryptData,
                decryptedKeys: typeof decryptData === 'object' ? Object.keys(decryptData) : 'not an object',
            }, 'Decryption successful');
        }
        req.body = decryptData;
        next();
    }
    catch (error) {
        const err = error;
        log.error({
            path: req.path,
            method: req.method,
            errorMessage: err.message,
            encryptedDataLength: encryptedData?.length || 0,
            encryptedPreview: encryptedData?.substring(0, 50) || 'N/A',
            stack: config('app.debugger') ? err.stack : undefined,
        }, 'Decryption failed');
        if (err.message.includes('Invalid JSON format after decryption')) {
            return res.error(400019004002, '请求数据格式错误：解密后的内容不是有效的JSON格式');
        }
        else if (err.message.includes('Invalid key or iv length')) {
            return res.error(500019004003, '服务器解密配置异常，请联系管理员');
        }
        else if (err.message.includes('Decryption failed')) {
            return res.error(400019004004, '请求数据解密失败，请检查数据格式和密钥');
        }
        next(error);
    }
};
//# sourceMappingURL=DecryptRequest.js.map