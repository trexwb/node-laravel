import { Container } from '../../Foundation/Container.js';
import { CacheService } from '../../Services/Cache/CacheService.js';
import { config } from '../../../bootstrap/configLoader.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
export const authenticateSecret = async (req, res, next) => {
    if (!Container.has('auth.secretProvider')) {
        return res.error(500000100001, 'AuthenticateSecret: auth.secretProvider not registered');
    }
    const secretProvider = Container.resolve('auth.secretProvider');
    const appId = req.headers['app-id'];
    const appSecret = req.headers['app-secret'];
    if (!appId || !appSecret) {
        return res.error(401000100001, 'appId/appSecret is empty');
    }
    const timeStampStr = appSecret.substring(appSecret.length - 10);
    const timeStamp = parseInt(timeStampStr) || 0;
    const tokenTime = parseInt(config('app.security.token_time') || '1800');
    const maxFutureSkew = parseInt(config('app.security.max_future_skew', 300) || '300');
    const now = Math.floor(Date.now() / 1000);
    if (timeStamp > now + maxFutureSkew) {
        return res.error(401000100002, 'appSecret timestamp is in the future');
    }
    if (timeStamp < now - tokenTime) {
        return res.error(401000100003, 'appSecret expiration');
    }
    const secretRow = await secretProvider(Number(appId));
    if (!secretRow || !secretRow.appId || !secretRow.appSecret) {
        return res.error(401000100004, 'appId/appSecret error');
    }
    if (!secretRow.status) {
        return res.error(403000100001, 'appSecret has been disabled');
    }
    const appStr = `${secretRow.appId}${timeStampStr}`;
    const expectedSecret = CryptoTool.hmacSha256(appStr, secretRow.appSecret) + timeStampStr;
    if (appSecret !== expectedSecret) {
        if (!config('app.security.legacy_md5_signature')) {
            return res.error(401000100005, 'appSecret verification failed');
        }
        const legacyAppStr = CryptoTool.sha256(`${secretRow.appId}${timeStampStr}`);
        const legacyExpectedSecret = CryptoTool.md5(`${legacyAppStr}${secretRow.appSecret}`) + timeStampStr;
        if (appSecret !== legacyExpectedSecret) {
            return res.error(401000100005, 'appSecret verification failed');
        }
        console.warn('[AuthenticateSecret] Legacy signature algorithm used, please upgrade client to HMAC-SHA256');
    }
    const nonce = req.headers['x-nonce'];
    if (nonce && nonce.length > 0 && nonce.length <= 128) {
        const nonceKey = `secret:nonce:${appId}:${nonce}`;
        const used = await CacheService.get(nonceKey);
        if (used) {
            return res.error(401000100006, 'appSecret nonce already used');
        }
        await CacheService.set(nonceKey, '1', tokenTime);
    }
    else {
        if (config('app.security.require_nonce')) {
            return res.error(401000100007, 'appSecret nonce required');
        }
        if (config('app.env') === 'production') {
            console.warn('[AuthenticateSecret] Request without X-Nonce in production — replay protection degraded');
        }
    }
    req.secretRow = secretRow;
    return next();
};
//# sourceMappingURL=AuthenticateSecret.js.map