import { BaseRequest } from '../Requests/BaseRequest.js';
export function validateRequest(RequestClass) {
    return async (req, _res, next) => {
        try {
            const instance = new RequestClass(req);
            const validated = await instance.validate();
            req.body = validated;
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
//# sourceMappingURL=ValidateRequest.js.map