import { config } from '../../../bootstrap/configLoader.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
import * as _ from 'lodash-es';
const SENSITIVE_PATHS = new Set([
    'password',
    'salt',
    'secret',
    'rememberToken',
    'appSecret',
    'appIv',
    'token',
    'accessToken',
    'refreshToken',
    'privateKey',
    'apiKey',
    'accessKeySecret',
    'accessKeyId',
]);
let warnedGlobalKey = false;
const omitByPath = (obj) => {
    if (Array.isArray(obj))
        return obj.map((v) => omitByPath(v));
    if (obj && typeof obj === 'object') {
        const out = {};
        for (const [key, value] of Object.entries(obj)) {
            if (SENSITIVE_PATHS.has(key))
                continue;
            out[key] = omitByPath(value);
        }
        return out;
    }
    return obj;
};
export const shapeData = (rawData, requestedFields) => {
    if (!rawData || typeof rawData !== 'object')
        return rawData;
    const pickIfNeeded = (item) => {
        const cleaned = omitByPath(item);
        return requestedFields?.length ? _.pick(cleaned, requestedFields) : cleaned;
    };
    if (Array.isArray(rawData)) {
        return rawData.map(pickIfNeeded);
    }
    if (Array.isArray(rawData.data)) {
        const paginated = rawData;
        return {
            ...paginated,
            data: paginated.data.map(pickIfNeeded),
        };
    }
    return pickIfNeeded(rawData);
};
export const encryptResponse = (req, res, next) => {
    const encryptEnabled = config('app.security.return_encrypt');
    const fieldsParam = req.query.fields;
    const requestedFields = fieldsParam
        ?.split(',')
        .map((f) => f.trim())
        .filter(Boolean);
    const originalJson = res.json;
    res.json = function (payload) {
        if (!payload || typeof payload !== 'object') {
            return originalJson.call(this, payload);
        }
        const p = payload;
        if (!p.data) {
            return originalJson.call(this, payload);
        }
        const shapedData = shapeData(p.data, requestedFields);
        if (!encryptEnabled) {
            p.data = shapedData;
            return originalJson.call(this, payload);
        }
        const appKey = req.secretRow?.appSecret || config('app.security.app_key');
        const appIv = req.secretRow?.appIv || config('app.security.app_iv');
        if (!req.secretRow?.appSecret && !warnedGlobalKey) {
            warnedGlobalKey = true;
            console.warn('[EncryptResponse] 未配置租户密钥（secretRow），正在使用全局 APP_KEY 加密响应');
        }
        p.encryptedData = CryptoTool.encrypt(JSON.stringify(shapedData), appKey, appIv);
        delete p.data;
        return originalJson.call(this, payload);
    };
    next();
};
//# sourceMappingURL=EncryptResponse.js.map