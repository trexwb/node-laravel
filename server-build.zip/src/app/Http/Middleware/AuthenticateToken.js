import { Container } from '../../Foundation/Container.js';
import { CacheService } from '../../Services/Cache/CacheService.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
export const authenticateToken = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        res.error(401000200001, 'Unauthorized: Missing Token');
        return;
    }
    const token = authHeader.split(' ')[1];
    try {
        const decryptedResult = CryptoTool.decryptToken(token);
        if (!decryptedResult || !decryptedResult.token || !decryptedResult.timeStamp) {
            res.error(401000200002, 'Unauthorized: Invalid Token Structure');
            return;
        }
        if (typeof decryptedResult.timeStamp !== 'number') {
            res.error(401000200003, 'Unauthorized: Invalid Timestamp');
            return;
        }
        const now = Math.floor(Date.now() / 1000);
        if (now > decryptedResult.timeStamp) {
            res.error(401000200004, 'Unauthorized: Token Expired');
            return;
        }
        if (typeof decryptedResult.jti === 'string' && decryptedResult.jti.length > 0) {
            const revoked = await CacheService.get(`token:blacklist:${decryptedResult.jti}`);
            if (revoked) {
                res.error(401000200007, 'Unauthorized: Token Revoked');
                return;
            }
        }
        if (!Container.has('auth.tokenUserProvider')) {
            res.error(500000100001, 'AuthenticateToken: auth.tokenUserProvider not registered');
            return;
        }
        const userProvider = Container.resolve('auth.tokenUserProvider');
        const userRow = await userProvider(decryptedResult.token);
        if (!userRow) {
            res.error(401000200005, 'Unauthorized: Invalid Token');
            return;
        }
        if (userRow.status === 0) {
            res.error(400000200006, 'User is disabled');
            return;
        }
        req.currentUser = userRow;
        req.tokenPayload = decryptedResult;
        next();
    }
    catch (error) {
        next(error);
    }
};
//# sourceMappingURL=AuthenticateToken.js.map