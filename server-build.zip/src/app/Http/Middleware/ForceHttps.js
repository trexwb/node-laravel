import { config } from '../../../bootstrap/configLoader.js';
export const forceHttps = (req, res, next) => {
    if (!req.secure) {
        const configuredHost = String(config('app.app_url') || '').replace(/^https?:\/\//, '');
        const host = configuredHost || req.headers.host;
        return res.redirect(`https://${host}${req.url}`);
    }
    next();
};
//# sourceMappingURL=ForceHttps.js.map