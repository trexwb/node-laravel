import { config } from '../../../bootstrap/configLoader.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
export function sortObjectDeep(obj) {
    if (Array.isArray(obj)) {
        return obj.map(sortObjectDeep);
    }
    else if (obj && typeof obj === 'object') {
        return Object.fromEntries(Object.entries(obj)
            .sort(([a], [b]) => {
            const aNum = /^\d+$/.test(a) ? Number(a) : null;
            const bNum = /^\d+$/.test(b) ? Number(b) : null;
            if (aNum !== null && bNum !== null)
                return aNum - bNum;
            if (aNum !== null)
                return -1;
            if (bNum !== null)
                return 1;
            return a.localeCompare(b);
        })
            .map(([k, v]) => [k, sortObjectDeep(v)]));
    }
    else {
        return obj;
    }
}
function getSigningKey(req) {
    if (req.secretRow?.appSecret) {
        return req.secretRow.appSecret;
    }
    console.warn('[VerifySignature] secretRow missing, falling back to global app_key');
    const fallbackKey = config('app.security.app_key');
    return fallbackKey;
}
export const verifySignature = (req, res, next) => {
    const isEnabled = config('app.security.verify_signature');
    if (!isEnabled)
        return next();
    const rawParams = { ...req.query, ...req.body };
    if (Object.keys(rawParams).length === 0)
        return next();
    const skipFields = [
        'file',
        'files',
        'filename',
        'buffer',
        'editorData',
        'html',
        'richText',
    ];
    const params = Object.keys(rawParams).reduce((acc, key) => {
        if (!skipFields.includes(key)) {
            acc[key] = rawParams[key];
        }
        return acc;
    }, {});
    const strictMode = config('app.security.strict_signature') ?? false;
    if (Object.keys(params).length === 0) {
        if (!strictMode) {
            return next();
        }
        const signEmpty = req.headers['x-sign'];
        if (!signEmpty) {
            return res.error(403019011001, 'Signature missing');
        }
        const appKeyEmpty = getSigningKey(req);
        const serverSignEmpty = CryptoTool.hmacSha256(CryptoTool.sha256(JSON.stringify({})), appKeyEmpty);
        if (signEmpty !== serverSignEmpty) {
            if (config('app.security.legacy_xsign_md5')) {
                const legacyEmpty = CryptoTool.md5(CryptoTool.sha256(JSON.stringify({})) + appKeyEmpty);
                if (signEmpty === legacyEmpty)
                    return next();
            }
            return res.error(403019011002, 'Invalid signature');
        }
        return next();
    }
    const sign = req.headers['x-sign'];
    if (!sign) {
        return res.error(403019011003, 'Signature missing');
    }
    const appKey = getSigningKey(req);
    const sortedParams = sortObjectDeep(params);
    const paramsDigest = CryptoTool.sha256(JSON.stringify(sortedParams));
    const serverSign = CryptoTool.hmacSha256(paramsDigest, appKey);
    if (sign !== serverSign) {
        if (config('app.security.legacy_xsign_md5')) {
            const legacySign = CryptoTool.md5(paramsDigest + appKey);
            if (sign === legacySign) {
                console.warn('[VerifySignature] Legacy x-sign algorithm used, please upgrade client to HMAC-SHA256');
                return next();
            }
        }
        return res.error(403019011004, 'Invalid signature');
    }
    next();
};
//# sourceMappingURL=VerifySignature.js.map