export const can = (permissionName) => {
    return async (req, res, next) => {
        const currentUser = req.currentUser;
        if (!currentUser) {
            res.error(401019003001, 'Unauthorized: user not exist');
            return;
        }
        const roles = currentUser.roles || [];
        if (!roles || !roles.length) {
            res.error(401019003002, 'Unauthorized: roles not exist');
            return;
        }
        const permissions = roles.flatMap((role) => role.permissionDetails?.map((p) => `${p.key}:${p.operation}`) ?? []);
        if (!permissions || !permissions.length) {
            res.error(401019003003, 'Unauthorized: permission not exist');
            return;
        }
        try {
            if (!permissions.includes(permissionName)) {
                res.error(403019003004, `Forbidden: Missing permission`);
                return;
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
};
//# sourceMappingURL=Authorize.js.map