import { Container } from '../../../Foundation/Container.js';
import { WebSocket, WebSocketServer } from 'ws';
export class ChannelController {
    static handleConnection(wss) {
        wss.on('connection', (ws) => {
            ws.on('message', (data) => ChannelController.handleMessage(ws, data));
            ws.on('close', () => {
                console.log('[WS] 客户端已断开');
            });
        });
    }
    static handleMessage(ws, data) {
        try {
            const text = Array.isArray(data)
                ? Buffer.concat(data).toString()
                : Buffer.isBuffer(data)
                    ? data.toString()
                    : Buffer.from(data).toString();
            const message = JSON.parse(text);
            const { channel, payload } = message;
            const handlers = Container.resolve('channel.handlers', () => ({}));
            const handler = handlers[channel];
            if (handler) {
                handler(ws, payload);
                return;
            }
            switch (channel) {
                case 'heartbeat':
                    ws.send(JSON.stringify({ event: 'pong' }));
                    break;
                default:
                    console.warn(`[WS] 未知的频道: ${channel}`);
                    ws.send(JSON.stringify({ error: 'Channel not found' }));
            }
        }
        catch {
            console.error('[WS] 消息格式错误，必须为 JSON');
        }
    }
}
//# sourceMappingURL=ChannelController.js.map