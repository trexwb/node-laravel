import { Container } from '../../../Foundation/Container.js';
import { getPagination } from '../../../Helpers/ControllerHelper.js';
import { ExampleUserService } from '../../../Services/Example/ExampleUserService.js';
export class ExampleController {
    static async index(req, res, _next) {
        const service = Container.resolve('example.userService', () => new ExampleUserService());
        const { page, pageSize } = getPagination(req.query);
        res.success(service.list(page, pageSize));
    }
    static async show(req, res, _next) {
        const service = Container.resolve('example.userService', () => new ExampleUserService());
        const id = Number(req.params.id);
        const user = service.find(id);
        if (!user) {
            res.error(404009001001, `用户不存在: id=${id}`);
            return;
        }
        res.success(user);
    }
    static async store(req, res, _next) {
        const service = Container.resolve('example.userService', () => new ExampleUserService());
        const body = req.body;
        if (!body.nickname || !body.email) {
            res.error(422009001002, 'nickname/email 不能为空');
            return;
        }
        const user = service.create({ nickname: body.nickname, email: body.email });
        res.success(user, 201, 'created');
    }
}
//# sourceMappingURL=ExampleController.js.map