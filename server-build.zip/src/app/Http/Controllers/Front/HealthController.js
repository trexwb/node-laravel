import { Container } from '../../../Foundation/Container.js';
export class HealthController {
    static healthCheck(_req, res, _next) {
        res.json({
            status: 'ok',
            pid: process.pid,
            uptime: Math.floor(process.uptime()),
            timestamp: new Date().toISOString(),
            version: process.env.npm_package_version || 'unknown',
        });
    }
    static async health(_req, res, _next) {
        res.success();
    }
    static async mockDate(req, res, _next) {
        res.success(req.body);
    }
    static async mockToken(_req, res, next) {
        try {
            const provider = Container.resolve('dev.mockTokenProvider', () => async () => null);
            res.success(await provider());
        }
        catch (error) {
            next(error);
        }
    }
}
//# sourceMappingURL=HealthController.js.map