import { Container } from '../../../Foundation/Container.js';
import { ExampleUserService } from '../../../Services/Example/ExampleUserService.js';
export class ExampleUserController {
    static async index(req, res, _next) {
        const service = Container.resolve('example.userService', () => new ExampleUserService());
        const page = Math.max(1, Number(req.query.page) || 1);
        const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize) || 10));
        const data = service.list(page, pageSize);
        res.success({
            requestId: req.id,
            currentUser: req.currentUser ? { id: req.currentUser.id, nickname: req.currentUser.nickname } : null,
            ...data,
        });
    }
    static async show(req, res, _next) {
        const service = Container.resolve('example.userService', () => new ExampleUserService());
        const user = service.find(Number(req.params.id));
        if (!user) {
            res.error(404009002001, '用户不存在');
            return;
        }
        res.success(user);
    }
}
//# sourceMappingURL=ExampleUserController.js.map