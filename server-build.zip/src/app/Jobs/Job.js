import { DatabaseQueueService } from '../Services/Queue/DatabaseQueueService.js';
export class Job {
    static async dispatch(params, delay = 0) {
        await DatabaseQueueService.dispatch(this.name, params, { delay });
    }
}
//# sourceMappingURL=Job.js.map