import { Container } from '../../Foundation/Container.js';
import knexConfig from '../../../database/knexfile.js';
import { formatDate } from '../../Helpers/format.js';
import { createLogger } from '../../Helpers/logger.js';
import knexLib from 'knex';
import { Model } from 'objection';
const log = createLogger('QueueWorker');
const POLL_INTERVAL_MS = 1000;
const BURST_INTERVAL_MS = 50;
const MAX_ATTEMPTS = 3;
const DB_WARMUP_INTERVAL_MS = 30000;
const RELEASE_TIMEOUT_SEC = 60;
export class QueueWorker {
    static running = false;
    static lastDbWarmupAt = 0;
    static async run() {
        if (this.running) {
            log.warn('Worker 已在运行中，忽略重复启动');
            return;
        }
        this.running = true;
        log.info({ pollIntervalMs: POLL_INTERVAL_MS, maxAttempts: MAX_ATTEMPTS }, '数据库队列 Worker 启动');
        this.setupGracefulShutdown();
        await this.warmupDb();
        while (this.running) {
            try {
                await this.ensureDbConnection();
                const hasJob = await this.pollAndProcess();
                if (!hasJob) {
                    await this.sleep(POLL_INTERVAL_MS);
                }
                else {
                    await this.sleep(BURST_INTERVAL_MS);
                }
            }
            catch (err) {
                const isConnErr = this.isConnectionError(err);
                log.error({ err: err?.message, isConnectionError: isConnErr }, '轮询循环异常');
                if (isConnErr) {
                    await this.reconnectDb();
                }
                await this.sleep(POLL_INTERVAL_MS);
            }
        }
        log.info('Worker 已关闭');
        process.exit(0);
    }
    static setupGracefulShutdown() {
        const shutdown = (signal) => {
            log.info({ signal }, '收到退出信号，正在关闭 Worker...');
            this.running = false;
        };
        process.on('SIGTERM', () => shutdown('SIGTERM'));
        process.on('SIGINT', () => shutdown('SIGINT'));
    }
    static async pollAndProcess() {
        const store = Container.resolve('queue.store');
        const job = await store.getNextAvailable();
        if (!job) {
            return false;
        }
        await this.processJob(job);
        return true;
    }
    static async processJob(job) {
        const jobId = job.id;
        const payload = typeof job.payload === 'string' ? JSON.parse(job.payload) : job.payload;
        const { className, params } = payload;
        log.info({ jobId, className, attempts: job.attempts, reservedAt: formatDate() }, '开始处理任务');
        try {
            const jobResolver = Container.resolve('queue.jobResolver', () => () => undefined);
            const JobClass = jobResolver(className);
            if (!JobClass) {
                throw new Error(`Job class '${className}' not found. Register it via 'queue.jobResolver'.`);
            }
            const instance = new JobClass(params);
            await instance.handle();
            await Container.resolve('queue.store').markDone(jobId);
            log.info({ jobId, className }, '任务处理成功');
        }
        catch (err) {
            log.error({ jobId, className, err: err?.message, attempts: job.attempts }, '任务处理失败');
            const newAttempts = job.attempts + 1;
            await Container.resolve('queue.store').markFailed(jobId, newAttempts, MAX_ATTEMPTS);
            log.warn({ jobId, className, attempts: newAttempts, maxAttempts: MAX_ATTEMPTS }, newAttempts >= MAX_ATTEMPTS ? '任务已失败（重试次数耗尽）' : '任务将在下次重试');
        }
    }
    static sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    static async warmupDb() {
        try {
            await Model.knex().raw('SELECT 1');
            this.lastDbWarmupAt = Date.now();
            log.info('DB 连接预热完成');
        }
        catch (err) {
            log.warn({ err: err?.message }, 'DB 预热失败，尝试重建连接');
            await this.reconnectDb();
        }
    }
    static async ensureDbConnection() {
        const now = Date.now();
        if (now - this.lastDbWarmupAt < DB_WARMUP_INTERVAL_MS)
            return;
        this.lastDbWarmupAt = now;
        try {
            await Model.knex().raw('SELECT 1');
            const released = await Container.resolve('queue.store').releaseTimedOutJobs(RELEASE_TIMEOUT_SEC);
            if (released > 0) {
                log.info({ released }, '已释放超时预留任务');
            }
        }
        catch (err) {
            log.warn({ err: err?.message }, 'DB 连接检测失败，尝试重连');
            await this.reconnectDb();
        }
    }
    static async reconnectDb() {
        try {
            const oldKnex = Model.knex();
            await oldKnex.destroy().catch(() => { });
            const newKnex = knexLib(knexConfig);
            Model.knex(newKnex);
            await newKnex.raw('SELECT 1');
            this.lastDbWarmupAt = Date.now();
            log.info('DB 连接已重建');
        }
        catch (err) {
            log.error({ err: err?.message }, '重建 DB 连接时出错，将在下次循环重试');
        }
    }
    static isConnectionError(err) {
        if (!err)
            return false;
        const errLike = err;
        const code = errLike.code || errLike.cause?.code || '';
        const msg = (errLike.message || '').toLowerCase();
        return (code === 'ECONNRESET' ||
            code === 'ECONNREFUSED' ||
            code === 'PROTOCOL_CONNECTION_LOST' ||
            code === 'PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR' ||
            code === 'ETIMEDOUT' ||
            msg.includes('connection lost') ||
            msg.includes('gone away') ||
            msg.includes('broken pipe') ||
            msg.includes('socket hang up'));
    }
}
//# sourceMappingURL=QueueWorker.js.map