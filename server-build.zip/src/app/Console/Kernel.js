import { Container } from '../Foundation/Container.js';
import { ScheduleChanged } from '../Events/System/ScheduleChanged.js';
import { eventBus } from '../../bootstrap/events.js';
import Utils from '../Helpers/index.js';
import { createLogger } from '../Helpers/logger.js';
import schedule from 'node-schedule';
const log = createLogger('Kernel');
export class Kernel {
    static taskJobs = new Map();
    static isInitializing = false;
    static isListening = false;
    static _reloadTimer = null;
    static listen() {
        if (this.isListening)
            return;
        this.isListening = true;
        eventBus.on(ScheduleChanged.eventName, () => this.requestReload());
    }
    static requestReload() {
        if (this._reloadTimer)
            clearTimeout(this._reloadTimer);
        this._reloadTimer = setTimeout(() => {
            this._reloadTimer = null;
            void this.schedule();
        }, 300);
    }
    static async schedule() {
        if (this.isInitializing)
            return;
        this.isInitializing = true;
        try {
            const taskRepository = Container.resolve('schedule.taskRepository', () => async () => []);
            const taskExecutor = Container.resolve('schedule.taskExecutor', () => async () => { });
            const taskData = (await taskRepository()) || [];
            const activeIds = new Set();
            if (Array.isArray(taskData)) {
                for (const row of taskData) {
                    const id = String(row.id);
                    if (row.status !== 1 || !Utils.isValidCronFormatFlexible(row.time)) {
                        continue;
                    }
                    activeIds.add(id);
                    const existing = this.taskJobs.get(id);
                    if (!existing || existing.time !== row.time) {
                        if (existing) {
                            existing.job.cancel();
                            log.info({ taskId: id }, '任务配置变更，重启中');
                        }
                        const newJob = schedule.scheduleJob(row.time, async () => {
                            await taskExecutor(row);
                        });
                        if (newJob) {
                            this.taskJobs.set(id, { job: newJob, time: row.time });
                        }
                    }
                }
            }
            for (const [id, { job }] of this.taskJobs.entries()) {
                if (!activeIds.has(id)) {
                    job.cancel();
                    this.taskJobs.delete(id);
                    log.info({ taskId: id }, '任务已停用/删除，释放资源');
                }
            }
        }
        catch (err) {
            log.error({ err }, '调度器严重错误');
        }
        finally {
            this.isInitializing = false;
        }
    }
}
//# sourceMappingURL=Kernel.js.map