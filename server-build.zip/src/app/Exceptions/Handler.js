import { config } from '../../bootstrap/configLoader.js';
import { createLogger } from '../Helpers/logger.js';
const log = createLogger('Handler');
const MESSAGE_CODE_MAP = [
    { pattern: 'not found', code: 400010000001, httpStatus: 404 },
    { pattern: '不存在', code: 400010000002, httpStatus: 404 },
    { pattern: 'Forbidden', code: 403000000001, httpStatus: 403 },
    { pattern: 'not belong', code: 403000000002, httpStatus: 403 },
    { pattern: '权限不足', code: 403000000003, httpStatus: 403 },
    { pattern: 'Unauthorized', code: 401000000001, httpStatus: 401 },
    { pattern: 'is required', code: 400010000010, httpStatus: 400 },
    { pattern: '不能为空', code: 400010000010, httpStatus: 400 },
    { pattern: 'Invalid', code: 400010000011, httpStatus: 400 },
    { pattern: '格式错误', code: 400010000011, httpStatus: 400 },
    { pattern: 'not a valid', code: 400010000011, httpStatus: 400 },
];
const KNOWN_SERVICE_ACTION = {
    'BaseModel.findById': { code: 404010000001, httpStatus: 404 },
    'BaseModel.transaction': { code: 500010000001, httpStatus: 500 },
};
function matchByMessage(msg) {
    const lower = msg.toLowerCase();
    return MESSAGE_CODE_MAP.find((e) => lower.includes(e.pattern.toLowerCase()));
}
function matchByServiceCode(code) {
    const [svc, action] = code.split('.');
    const key = `${svc}.${action}`;
    return KNOWN_SERVICE_ACTION[key];
}
function resolveErrorCode(err) {
    if (typeof err.errorCode === 'number') {
        return { code: err.errorCode, httpStatus: err.statusCode || 400 };
    }
    const msg = err.message ?? '';
    const entry = matchByMessage(msg);
    if (entry)
        return { code: entry.code, httpStatus: entry.httpStatus };
    if (typeof err.code === 'string' && err.code.includes('.')) {
        const mapped = matchByServiceCode(err.code);
        if (mapped)
            return mapped;
        log.warn({ err, code: err.code }, 'Handler: unhandled service.action, fallback 500010000001');
        return { code: 500010000001, httpStatus: 500 };
    }
    return { code: 500010000001, httpStatus: 500 };
}
export class Handler {
    static render(err, req, res, _next) {
        const { code, httpStatus } = resolveErrorCode(err);
        const msg = httpStatus >= 500 && config('app.env') === 'production' && !config('app.debugger')
            ? 'Internal Server Error'
            : err.message || 'Internal Server Error';
        if (httpStatus >= 500) {
            const logData = {
                err,
                method: req.method,
                path: req.path,
                httpStatus,
                code,
            };
            if (msg.includes('Encryption failed') || msg.includes('Invalid JSON format')) {
                logData.module = 'Middleware:Decrypt';
                logData.url = req.url;
                logData.query = req.query;
                logData.headers = {
                    'content-type': req.headers['content-type'],
                    'content-length': req.headers['content-length'],
                    'user-agent': req.headers['user-agent'],
                };
                const bodyStr = typeof req.body === 'string' ? req.body : JSON.stringify(req.body ?? {});
                logData.body_preview = bodyStr.substring(0, 200) + (bodyStr.length > 200 ? '...' : '');
                if (config('app.debugger')) {
                    logData.ip = req.ip;
                    logData.originalUrl = req.originalUrl;
                    if (typeof req.body?.encryptedData === 'string') {
                        logData.encrypted_preview = req.body.encryptedData.substring(0, 100);
                        logData.encrypted_length = req.body.encryptedData.length;
                    }
                }
            }
            log.error(logData, '服务端异常');
        }
        res.status(httpStatus).json({
            msg,
            code,
            stack: config('app.debugger') ? err.stack : undefined,
        });
    }
}
//# sourceMappingURL=Handler.js.map