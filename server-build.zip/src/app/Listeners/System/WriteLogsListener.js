import { WriteLogs } from '../../Events/System/WriteLogs.js';
import { Container } from '../../Foundation/Container.js';
import { eventBus } from '../../../bootstrap/events.js';
import * as _ from 'lodash-es';
const clone = (data) => (structuredClone ? structuredClone(data) : _.cloneDeep(data));
const SENSITIVE_FIELDS = new Set([
    'password',
    'salt',
    'secret',
    'rememberToken',
    'token',
    'accessToken',
    'refreshToken',
    'apiKey',
    'privateKey',
    'appSecret',
    'appIv',
]);
function sanitizeSourceForLog(source) {
    const cloned = clone(source);
    const result = {};
    for (const [key, value] of Object.entries(cloned)) {
        if (SENSITIVE_FIELDS.has(key))
            continue;
        if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
            result[key] = sanitizeSourceForLog(value);
        }
        else {
            result[key] = value;
        }
    }
    return result;
}
export class WriteLogsListener {
    static _listening = false;
    static listen() {
        if (this._listening)
            return;
        this._listening = true;
        eventBus.on(WriteLogs.eventName, (payload) => {
            this.handle(payload).catch((err) => {
                console.error('[WriteLogsListener] handle error:', err);
            });
        });
    }
    static async handle(payload) {
        const { source, handle, action } = payload;
        const registry = Container.resolve('logs.sinkRegistry', () => () => undefined);
        const sink = registry(action);
        if (!sink)
            return;
        await sink.insert({
            source: sanitizeSourceForLog(source),
            handle: { ...sanitizeSourceForLog(handle), action },
        });
    }
}
//# sourceMappingURL=WriteLogsListener.js.map