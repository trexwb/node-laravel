import { eventBus } from '../../../bootstrap/events.js';
export class CacheInvalidatedListener {
    static EVENT = 'system.cache_invalidated';
    static _listening = false;
    static listen() {
        if (this._listening)
            return;
        this._listening = true;
        eventBus.on(this.EVENT, (payload) => {
            this.handle(payload).catch((err) => console.error('[CacheInvalidatedListener] handle error', err));
        });
    }
    static emit(payload) {
        eventBus.emit(this.EVENT, payload);
    }
    static async handle(payload) {
        console.log(`[CacheInvalidated] module=${payload.module} pattern=${payload.pattern}` + (payload.triggeredBy ? ` by=${payload.triggeredBy}` : ''));
    }
}
//# sourceMappingURL=CacheInvalidatedListener.js.map