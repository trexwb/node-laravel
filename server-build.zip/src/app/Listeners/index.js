export { BaseListener } from './BaseListener.js';
import { CacheInvalidatedListener } from './System/CacheInvalidatedListener.js';
import { WriteLogsListener } from './System/WriteLogsListener.js';
export function registerAllListeners() {
    CacheInvalidatedListener.listen();
    WriteLogsListener.listen();
    console.log('[Listeners] All listeners registered.');
}
export { CacheInvalidatedListener, WriteLogsListener };
//# sourceMappingURL=index.js.map