import { eventBus } from '../../bootstrap/events.js';
export class BaseListener {
    static eventName;
    static _listening = false;
    static get listening() {
        return this._listening;
    }
    static listenOn(eventName, handler) {
        if (this._listening)
            return;
        this._listening = true;
        eventBus.on(eventName, (payload) => {
            handler(payload).catch((err) => {
                console.error(`[${this.name}] handle error:`, err);
            });
        });
    }
    static async executeAll(tasks) {
        await Promise.allSettled(tasks);
    }
    static async safeExecute(fn, errorMsg) {
        try {
            return await fn();
        }
        catch (err) {
            console.error(`[this.name] ${errorMsg}:`, err);
            return null;
        }
    }
}
//# sourceMappingURL=BaseListener.js.map