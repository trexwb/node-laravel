import { config } from '../../bootstrap/configLoader.js';
import { DEFAULT_TIME_ZONE, formatDateFromUTC, formatDbDateTimeFromUTC, nowDate } from '../Helpers/format.js';
import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone.js';
import utc from 'dayjs/plugin/utc.js';
import * as _ from 'lodash-es';
import { Model, QueryBuilder, snakeCaseMappers } from 'objection';
dayjs.extend(utc);
dayjs.extend(timezone);
function getSchemaProps(ctor) {
    return ctor.jsonSchema?.properties;
}
function normalizeTypes(type) {
    if (!type)
        return [];
    return Array.isArray(type) ? type.map(String) : [String(type)];
}
export class BaseModel extends Model {
    static table;
    static primaryKey = 'id';
    static fillable = [];
    static hidden = [];
    static casts = {};
    static useTimestamps = true;
    static inserTable = [];
    static softDelete = false;
    static softDeleteColumn = 'deletedAt';
    static sanitizeValue(value, prop) {
        if (value === null || value === undefined)
            return value;
        if (prop.format === 'date-time' || prop.format === 'date') {
            return this.coerceDateTime(value, prop.format);
        }
        if (prop.format === 'email') {
            if (typeof value === 'string')
                return value.trim().toLowerCase();
            return value;
        }
        if (prop.format === 'uuid') {
            if (typeof value === 'string') {
                const normalized = value.trim().toLowerCase();
                if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(normalized)) {
                    return normalized;
                }
            }
            return value;
        }
        const types = normalizeTypes(prop.type).filter((t) => t !== 'null');
        for (const t of types) {
            switch (t) {
                case 'integer': {
                    let n;
                    if (typeof value === 'number') {
                        n = value;
                    }
                    else {
                        n = Number(value);
                        if (!Number.isFinite(n))
                            return value;
                    }
                    let rounded = Math.round(n);
                    if (prop.minimum !== undefined)
                        rounded = Math.max(rounded, prop.minimum);
                    if (prop.maximum !== undefined)
                        rounded = Math.min(rounded, prop.maximum);
                    return rounded;
                }
                case 'number': {
                    if (typeof value === 'number') {
                        let n = value;
                        if (prop.minimum !== undefined)
                            n = Math.max(n, prop.minimum);
                        if (prop.maximum !== undefined)
                            n = Math.min(n, prop.maximum);
                        return n;
                    }
                    const n = Number(value);
                    if (!Number.isFinite(n))
                        return value;
                    if (prop.minimum !== undefined)
                        return Math.max(n, prop.minimum);
                    if (prop.maximum !== undefined)
                        return Math.min(n, prop.maximum);
                    return n;
                }
                case 'boolean': {
                    if (typeof value === 'boolean')
                        return value;
                    if (value === 'true' || value === '1' || value === 1)
                        return true;
                    if (value === 'false' || value === '0' || value === 0)
                        return false;
                    return value;
                }
                case 'object': {
                    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                        if (prop.properties || prop.additionalProperties !== undefined) {
                            return this.coerceObject(value, prop);
                        }
                    }
                    if (typeof value === 'string') {
                        try {
                            return JSON.parse(value);
                        }
                        catch {
                            return value;
                        }
                    }
                    return value;
                }
                case 'array': {
                    if (Array.isArray(value)) {
                        return this.coerceArray(value, prop);
                    }
                    if (typeof value === 'string') {
                        try {
                            return this.coerceArray(JSON.parse(value), prop);
                        }
                        catch {
                            return value;
                        }
                    }
                    return value;
                }
                case 'string': {
                    let str;
                    if (value instanceof Date) {
                        if (isNaN(value.getTime()))
                            return null;
                        str = value.toISOString();
                    }
                    else if (typeof value === 'object' && value !== null) {
                        str = JSON.stringify(value);
                    }
                    else {
                        str = String(value);
                    }
                    if (prop.pattern) {
                        try {
                            str = str.replace(/[^a-zA-Z0-9_\-\s@.+]/g, '_');
                        }
                        catch {
                        }
                    }
                    if (prop.minLength !== undefined && str.length < prop.minLength) {
                        str = str.padEnd(prop.minLength, ' ');
                    }
                    if (prop.maxLength !== undefined && str.length > prop.maxLength) {
                        str = str.slice(0, prop.maxLength);
                    }
                    return str;
                }
            }
        }
        return value;
    }
    static sanitize(data) {
        const props = getSchemaProps(this);
        if (!props)
            return { ...data };
        const result = {};
        for (const [key, value] of Object.entries(data)) {
            const prop = props[key];
            if (!prop) {
                result[key] = value;
                continue;
            }
            let sanitized = this.sanitizeValue(value, prop);
            if (typeof sanitized === 'string') {
                sanitized = sanitized
                    .trim()
                    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
            }
            result[key] = sanitized;
        }
        return result;
    }
    static coerceDateTime(value, format) {
        if (value instanceof Date) {
            if (isNaN(value.getTime()))
                return null;
            return format === 'date-time' ? formatDbDateTimeFromUTC(value) : formatDateFromUTC(value, 'YYYY-MM-DD');
        }
        if (typeof value === 'string' && value.trim()) {
            const raw = value.trim();
            if (format === 'date-time' && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
                return raw;
            }
            if (format === 'date' && /^\d{4}-\d{2}-\d{2}$/.test(raw)) {
                return raw;
            }
            try {
                const parsed = dayjs.tz(raw, DEFAULT_TIME_ZONE);
                if (parsed.isValid()) {
                    return format === 'date-time' ? parsed.format('YYYY-MM-DD HH:mm:ss') : parsed.format('YYYY-MM-DD');
                }
            }
            catch {
            }
        }
        if (typeof value === 'number') {
            if (!Number.isFinite(value))
                return value;
            const ts = value > 1e12 ? value : value * 1000;
            return format === 'date-time' ? formatDbDateTimeFromUTC(new Date(ts)) : formatDateFromUTC(new Date(ts), 'YYYY-MM-DD');
        }
        return value;
    }
    static coerceObject(value, prop) {
        if (typeof value !== 'object' || value === null || Array.isArray(value))
            return value;
        const result = {};
        const definedProps = prop.properties || {};
        const additionalProps = prop.additionalProperties;
        for (const [k, v] of Object.entries(value)) {
            if (k in definedProps) {
                result[k] = this.sanitizeValue(v, definedProps[k]);
                continue;
            }
            if (additionalProps === false)
                continue;
            result[k] = v;
        }
        return result;
    }
    static coerceArray(value, prop) {
        if (!Array.isArray(value))
            return value;
        let items = value;
        if (prop.uniqueItems) {
            const seen = new Set();
            items = items.filter((v) => {
                const key = typeof v === 'object' ? JSON.stringify(v) : String(v);
                if (seen.has(key))
                    return false;
                seen.add(key);
                return true;
            });
        }
        if (prop.minItems !== undefined && items.length < prop.minItems) {
            items = [...items, ...Array(prop.minItems - items.length).fill(null)];
        }
        if (prop.maxItems !== undefined && items.length > prop.maxItems) {
            items = items.slice(0, prop.maxItems);
        }
        if (prop.items) {
            items = items.map((v) => this.sanitizeValue(v, prop.items));
        }
        return items;
    }
    $beforeValidate(jsonSchema, json, _opt) {
        const props = getSchemaProps(this.constructor);
        if (!props)
            return jsonSchema;
        for (const key of Object.keys(json)) {
            const val = json[key];
            if (val === null || val === undefined)
                continue;
            const prop = props?.[key];
            if (!prop)
                continue;
            const types = normalizeTypes(prop.type);
            if (typeof val === 'string') {
                let trimmed = val.trim().replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
                if (types.includes('integer') || types.includes('number')) {
                    if (/^-?(\d+\.?\d*|\.\d+)$/.test(trimmed)) {
                        json[key] = types.includes('integer') ? parseInt(trimmed, 10) : parseFloat(trimmed);
                        continue;
                    }
                }
                if (types.includes('boolean')) {
                    if (trimmed === 'true' || trimmed === '1') {
                        json[key] = true;
                        continue;
                    }
                    if (trimmed === 'false' || trimmed === '0') {
                        json[key] = false;
                        continue;
                    }
                }
                if (prop.format === 'date-time') {
                    if (trimmed === 'null' || trimmed === '') {
                        json[key] = null;
                        continue;
                    }
                }
                json[key] = trimmed;
                continue;
            }
        }
        return jsonSchema;
    }
    $parseJson(json) {
        json = super.$parseJson(json);
        const props = getSchemaProps(this.constructor);
        if (!props)
            return json;
        for (const [key, prop] of Object.entries(props)) {
            if (!(key in json))
                continue;
            const val = json[key];
            if (val === null || val === undefined)
                continue;
            json[key] = this.constructor.sanitizeValue(val, prop);
        }
        return json;
    }
    $parseDatabaseJson(json) {
        json = super.$parseDatabaseJson(json);
        for (const key of Object.keys(json)) {
            const value = json[key];
            const prop = getSchemaProps(this.constructor)?.[key];
            const isDateTimeField = key.endsWith('At') || key.endsWith('_at') || prop?.format === 'date-time';
            if (!isDateTimeField || value === null || value === undefined)
                continue;
            if (value instanceof Date) {
                json[key] = formatDateFromUTC(value);
                continue;
            }
            if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(value)) {
                json[key] = formatDateFromUTC(value);
            }
        }
        return json;
    }
    $formatDatabaseJson(json) {
        const formatted = super.$formatDatabaseJson(json);
        const props = getSchemaProps(this.constructor);
        const result = {};
        for (const [key, value] of Object.entries(formatted)) {
            const camelKey = _.camelCase(key);
            if (props && !(key in props) && !(camelKey in props))
                continue;
            const prop = props?.[key] ?? props?.[camelKey];
            result[key] = this.formatForDb(key, value, prop);
        }
        return result;
    }
    formatDateTimeForDb(value) {
        if (value === null || value === undefined)
            return value;
        if (value instanceof Date) {
            if (isNaN(value.getTime()))
                return null;
            return formatDbDateTimeFromUTC(value);
        }
        if (typeof value === 'string') {
            const raw = value.trim();
            if (!raw)
                return null;
            if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw))
                return raw;
            try {
                const parsed = raw.endsWith('Z') || /^\d{4}-\d{2}-\d{2}T/.test(raw) || /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[+\-]\d{2}:?\d{2}$/.test(raw)
                    ? dayjs.utc(raw).tz(DEFAULT_TIME_ZONE)
                    : dayjs.tz(raw, DEFAULT_TIME_ZONE);
                return parsed.isValid() ? parsed.format('YYYY-MM-DD HH:mm:ss') : raw;
            }
            catch {
                return raw;
            }
        }
        if (typeof value === 'number') {
            if (!Number.isFinite(value))
                return null;
            return formatDbDateTimeFromUTC(value);
        }
        return value;
    }
    formatForDb(key, value, prop) {
        if (value === null || value === undefined)
            return value;
        const isAtField = key.endsWith('At') || key.endsWith('_at');
        if (isAtField || prop?.format === 'date-time')
            return this.formatDateTimeForDb(value);
        if (prop?.format === 'date') {
            if (value instanceof Date) {
                if (isNaN(value.getTime()))
                    return null;
                return formatDateFromUTC(value, 'YYYY-MM-DD');
            }
        }
        if (value instanceof Date) {
            if (isNaN(value.getTime()))
                return null;
            return formatDbDateTimeFromUTC(value);
        }
        if (typeof value === 'boolean')
            return value ? 1 : 0;
        if (typeof value === 'object') {
            return JSON.stringify(value);
        }
        return value;
    }
    $formatJson(json) {
        json = super.$formatJson(json);
        for (const key of Object.keys(json)) {
            const value = json[key];
            const prop = getSchemaProps(this.constructor)?.[key];
            const isDateTimeField = key.endsWith('At') || key.endsWith('_at') || prop?.format === 'date-time';
            if (!isDateTimeField)
                continue;
            if (value instanceof Date) {
                json[key] = formatDateFromUTC(value);
            }
            else if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(value)) {
                json[key] = formatDateFromUTC(value);
            }
        }
        return json;
    }
    getUpdatedAtAttribute(value) {
        return formatDateFromUTC(value);
    }
    getCreatedAtAttribute(value) {
        return formatDateFromUTC(value);
    }
    $beforeInsert() {
        this.enforceEnums();
        if (this.constructor.useTimestamps) {
            const now = nowDate();
            Object.assign(this, { createdAt: now, updatedAt: now });
        }
    }
    $beforeUpdate() {
        this.enforceEnums();
        if (this.constructor.useTimestamps) {
            Object.assign(this, { updatedAt: nowDate() });
        }
    }
    enforceEnums() {
        const props = getSchemaProps(this.constructor);
        if (!props)
            return;
        for (const [key, prop] of Object.entries(props)) {
            if (!prop.enum)
                continue;
            const val = this[key];
            if (val === undefined || val === null)
                continue;
            const matchesEnum = prop.enum.some((e) => String(e) === String(val) || Number(e) === Number(val));
            if (!matchesEnum) {
                const err = new Error(`字段 "${key}" 值 "${val}" 不在允许的枚举值内：[${prop.enum.join(', ')}]`);
                err.code = 'ENUM_VIOLATION';
                err.field = key;
                throw err;
            }
        }
    }
    static coerceSchemaTypes(data) {
        const props = getSchemaProps(this);
        if (!props)
            return data;
        const result = { ...data };
        for (const [key, prop] of Object.entries(props)) {
            if (!(key in result))
                continue;
            result[key] = this.sanitizeValue(result[key], prop);
        }
        return result;
    }
    static filterSchemaFields(data) {
        if (!data || typeof data !== 'object')
            return {};
        const props = this.jsonSchema?.properties;
        if (props) {
            return Object.fromEntries(Object.entries(data).filter(([key]) => key in props));
        }
        if (this.inserTable?.length) {
            return Object.fromEntries(Object.entries(data).filter(([key]) => this.inserTable.includes(key)));
        }
        return { ...data };
    }
    static runAccessors(data) {
        const proto = this.prototype;
        const methods = Object.getOwnPropertyNames(this).concat(Object.getOwnPropertyNames(proto));
        const staticCtx = this;
        methods.forEach((method) => {
            if (method.startsWith('get') && method.endsWith('Attribute')) {
                const field = _.snakeCase(method.replace('get', '').replace('Attribute', ''));
                if (data[field] !== undefined && typeof staticCtx[method] === 'function') {
                    data[field] = staticCtx[method](data[field]);
                }
            }
        });
        return data;
    }
    static runMutators(data) {
        const staticCtx = this;
        for (const key in data) {
            const methodName = `set${_.upperFirst(_.camelCase(key))}Attribute`;
            const mutator = staticCtx[methodName];
            if (typeof mutator === 'function') {
                data[key] = mutator(data[key]);
            }
        }
        return data;
    }
    static runCasts(data, type) {
        const result = { ...data };
        for (const key in this.casts) {
            const caster = this.casts[key];
            if (result[key] !== undefined && typeof caster !== 'string') {
                result[key] = type === 'get' ? caster.get(result[key]) : caster.set(result[key]);
            }
        }
        return result;
    }
    static columnNameMappers = snakeCaseMappers();
    static get createdAtColumn() {
        return 'createdAt';
    }
    static get updatedAtColumn() {
        return 'updatedAt';
    }
    static getSchemaDbColumns() {
        const props = Object.keys(this.jsonSchema?.properties ?? {});
        const mapper = this.columnNameMappers;
        if (!mapper?.format)
            return props;
        return props.map((prop) => {
            const mapped = mapper.format({ [prop]: null });
            return Object.keys(mapped)[0];
        });
    }
    static applyOrder(query, order) {
        const normalized = [];
        if (Array.isArray(order)) {
            for (const item of order) {
                if (!item || typeof item.column !== 'string' || item.column.trim() === '')
                    continue;
                normalized.push({
                    column: item.column,
                    order: item.order?.toUpperCase() === 'DESC' ? 'DESC' : 'ASC',
                });
            }
        }
        else if (order && typeof order === 'object' && 'column' in order && typeof order.column === 'string') {
            const column = order.column;
            if (column.trim() !== '') {
                normalized.push({
                    column,
                    order: order.order?.toUpperCase() === 'DESC' ? 'DESC' : 'ASC',
                });
            }
        }
        const hasSortField = this.jsonSchema?.properties && Object.keys(this.jsonSchema.properties).includes('sort');
        if (hasSortField) {
            query.orderByRaw('CASE WHEN ??.?? > 0 THEN 1 ELSE 0 END DESC', [this.tableName, 'sort']);
            const callerHasSort = normalized.some((v) => v.column === 'sort' || v.column.endsWith('.sort'));
            if (!callerHasSort) {
                query.orderByRaw('??.?? ASC', [this.tableName, 'sort']);
            }
        }
        const sortableColumns = this.getSortableColumns();
        const safeOrder = sortableColumns.size > 0 ? normalized.filter((item) => this.isSortableColumn(item.column, sortableColumns)) : normalized;
        if (safeOrder.length > 0) {
            for (const item of safeOrder) {
                query.orderBy(item.column, item.order.toLowerCase());
            }
            return query;
        }
        if (!hasSortField) {
            query.orderBy('id', 'asc');
        }
        return query;
    }
    static getSortableColumns() {
        const props = Object.keys(this.jsonSchema?.properties ?? {});
        const columns = new Set(props);
        const mapper = this.columnNameMappers;
        if (mapper && typeof mapper.format === 'function') {
            for (const prop of props) {
                try {
                    const mapped = Object.keys(mapper.format({ [prop]: null }))[0];
                    if (mapped)
                        columns.add(mapped);
                }
                catch {
                }
            }
        }
        return columns;
    }
    static isSortableColumn(column, sortableColumns) {
        if (sortableColumns.has(column))
            return true;
        const dotIdx = column.lastIndexOf('.');
        if (dotIdx > 0) {
            return sortableColumns.has(column.slice(dotIdx + 1));
        }
        return false;
    }
    static buildQuery(query = this.query(), _filters = {}, _trashed = false) {
        if (config('app.debugger') === true) {
            console.debug('[SQL]', query.toKnexQuery().toSQL().toNative());
        }
        const table = this.tableName;
        if (this.softDelete === true) {
            const col = this.softDeleteColumn || 'deleted_at';
            if (_trashed) {
                query.whereNotNull(`${table}.${col}`);
            }
            else {
                query.whereNull(`${table}.${col}`);
            }
        }
        const filters = _filters || {};
        if (filters && typeof filters === 'object') {
            const id = filters.id;
            if (id !== undefined && id !== null) {
                const apply = (field, value, isNot = false) => {
                    const isArr = Array.isArray(value);
                    if (isNot) {
                        isArr ? query.whereNotIn(field, value) : query.whereNot(field, value);
                    }
                    else {
                        isArr ? query.whereIn(field, value) : query.where(field, value);
                    }
                };
                if (typeof id === 'object' && !Array.isArray(id)) {
                    if (id.eq !== undefined)
                        apply(`${table}.id`, id.eq);
                    if (id.not !== undefined)
                        apply(`${table}.id`, id.not, true);
                }
                else {
                    apply(`${table}.id`, id);
                }
            }
        }
        return query;
    }
    static async findById(id) {
        return (await this.query().findById(id));
    }
    static async findOne(filters = {}, trashed = false) {
        const query = this.buildQuery(this.query(), filters, trashed);
        return (await query.first());
    }
    static async findAll(filters = {}, options = {}, trashed = false) {
        const { order } = options;
        const baseQuery = this.buildQuery(this.query(), filters, trashed);
        this.applyOrder(baseQuery, order);
        return (await baseQuery);
    }
    static async findMany(filters = {}, options = {}, trashed = false) {
        const { page = 1, pageSize = 10, order } = options;
        const offset = (page - 1) * pageSize;
        const baseQuery = this.buildQuery(this.query(), filters, trashed);
        const countQuery = baseQuery.clone();
        const dataQuery = baseQuery.clone();
        const total = await countQuery.resultSize();
        this.applyOrder(dataQuery, order);
        const data = (await dataQuery.limit(pageSize).offset(offset));
        return {
            data,
            meta: {
                total,
                page,
                pageSize,
                totalPages: Math.ceil(total / pageSize),
            },
        };
    }
    static prepareData(data, opts = {}) {
        let d = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, v === undefined ? null : v]));
        if (opts.filter) {
            const filtered = this.filterSchemaFields(d);
            if (!filtered || Object.keys(filtered).length === 0)
                return {};
            d = filtered;
        }
        d = this.runMutators(d);
        d = this.runCasts(d, 'set');
        d = this.coerceSchemaTypes(d);
        return d;
    }
    static async insert(data) {
        let d = this.prepareData(data);
        if (this.inserTable.length) {
            const filtered = Object.fromEntries(Object.entries(d).filter(([key]) => this.inserTable.includes(key)));
            if (Object.keys(filtered).length === 0) {
                const err = new Error(`No valid fields to insert for table ${this.tableName}.`);
                err.code = 'BaseModel:insert:emptyFields';
                throw err;
            }
            d = filtered;
        }
        const inserted = (await this.query().insertAndFetch(d));
        let json = inserted.toJSON();
        json = this.runAccessors(json);
        json = this.runCasts(json, 'get');
        return Object.assign(Object.create(this.prototype), json);
    }
    static async insertMany(data) {
        if (data.length === 0)
            return [];
        const inserted = [];
        await this.transaction(async (trx) => {
            for (const item of data) {
                let d = this.prepareData(item);
                if (this.inserTable.length) {
                    const filtered = Object.fromEntries(Object.entries(d).filter(([key]) => this.inserTable.includes(key)));
                    if (Object.keys(filtered).length > 0)
                        d = filtered;
                }
                const result = await this.query(trx).insert(d);
                inserted.push(result);
            }
        });
        return inserted;
    }
    static async modifyById(id, data) {
        const d = this.prepareData(data, { filter: true });
        const { id: _, ...patchData } = d;
        if (Object.keys(patchData).length === 0)
            return null;
        return (await this.query().patchAndFetchById(id, patchData));
    }
    static async modifyByFilters(filters = {}, data) {
        this.assertNonEmptyFilter(filters, 'modifyByFilters');
        const d = this.prepareData(data, { filter: true });
        if (Object.keys(d).length === 0)
            return 0;
        if (this.useTimestamps) {
            Object.assign(d, { updatedAt: nowDate() });
        }
        const query = this.buildQuery(this.query(), filters);
        return await query.patch(d);
    }
    static async restoreById(id) {
        if (this.softDelete) {
            return await this.query()
                .where('id', id)
                .patch({ [this.softDeleteColumn]: null });
        }
        return null;
    }
    static async restoreByFilters(filters = {}) {
        const query = this.buildQuery(this.query(), filters);
        if (this.softDelete) {
            return await query.patch({ [this.softDeleteColumn]: null });
        }
        return null;
    }
    static async deleteById(id) {
        if (this.softDelete) {
            return await this.query()
                .where('id', id)
                .patch({ [this.softDeleteColumn]: nowDate() });
        }
        return await this.query().deleteById(id);
    }
    static async deleteByFilters(filters = {}) {
        this.assertNonEmptyFilter(filters, 'deleteByFilters');
        const query = this.buildQuery(this.query(), filters);
        if (this.softDelete) {
            return await query.patch({ [this.softDeleteColumn]: nowDate() });
        }
        return await query.delete();
    }
    static async forceDelete(filters = {}) {
        if (this.softDelete === true) {
            const query = this.buildQuery(this.query(), filters, true);
            const count = await query.resultSize();
            if (count === 0) {
                const err = new Error(`No soft-deleted record found matching the given filters — ` +
                    `force delete requires the record to be soft-deleted first. ` +
                    `Table: ${this.tableName}`);
                err.code = 'BaseModel:forceDelete:notSoftDeleted';
                throw err;
            }
            return await query.delete();
        }
        const query = this.buildQuery(this.query(), filters);
        return await query.delete();
    }
    static assertNonEmptyFilter(filters, method) {
        if (!filters || typeof filters !== 'object' || Object.keys(filters).length === 0) {
            const err = new Error(`${method} requires a non-empty filter — refusing batch operation on the whole table. ` + `Table: ${this.tableName}`);
            err.code = 'BaseModel:batchOp:emptyFilter';
            throw err;
        }
    }
}
//# sourceMappingURL=BaseModel.js.map