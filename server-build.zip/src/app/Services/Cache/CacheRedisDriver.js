import { config } from '../../../bootstrap/configLoader.js';
import { createClient } from 'redis';
export class RedisDriver {
    client;
    prefix;
    readyPromise;
    constructor() {
        const host = config('cache.host');
        const port = config('cache.port');
        const password = config('cache.passwd');
        this.prefix = config('cache.prefix') || '';
        this.client = createClient({
            password,
            socket: {
                host,
                port,
            },
        });
        this.client.on('error', (err) => {
            console.error('Redis Client Error:', err);
        });
        this.readyPromise = this.client
            .connect()
            .then(() => {
            console.log(`[CacheRedisDriver] Connected to Redis ${host}:${port}`);
        })
            .catch((err) => {
            console.error('[CacheRedisDriver] Failed to connect to Redis:', err);
        });
    }
    async ensureReady() {
        await this.readyPromise;
        if (!this.client.isReady) {
            await new Promise((resolve) => {
                const check = () => {
                    if (this.client.isReady) {
                        resolve();
                    }
                    else {
                        setTimeout(check, 10);
                    }
                };
                check();
            });
        }
    }
    async get(key) {
        await this.ensureReady();
        const val = await this.client.get(this.prefix + key);
        if (!val)
            return null;
        try {
            return JSON.parse(val);
        }
        catch {
            return val;
        }
    }
    async set(key, value, ttl = 3600) {
        await this.ensureReady();
        const val = typeof value === 'object' ? JSON.stringify(value) : String(value);
        await this.client.set(this.prefix + key, val, {
            EX: ttl,
        });
    }
    async forget(key) {
        await this.ensureReady();
        if (!key)
            return;
        await this.client.del(this.prefix + key);
    }
    async flush() {
        await this.ensureReady();
        await this.client.flushDb();
    }
    async forgetByPattern(pattern) {
        await this.ensureReady();
        const match = `${this.prefix}${pattern}*`;
        const batch = [];
        let totalScanned = 0;
        let totalDeleted = 0;
        const flush = async () => {
            if (batch.length === 0)
                return;
            const keys = batch.splice(0, batch.length).filter(Boolean);
            if (keys.length === 0)
                return;
            const deleted = await this.client.del(keys);
            totalDeleted += deleted;
        };
        try {
            for await (const item of this.client.scanIterator({ MATCH: match })) {
                if (!item)
                    continue;
                if (Array.isArray(item)) {
                    for (const k of item)
                        if (k) {
                            batch.push(k);
                            totalScanned++;
                        }
                }
                else {
                    batch.push(item);
                    totalScanned++;
                }
                if (batch.length >= 500)
                    await flush();
            }
            await flush();
        }
        catch (err) {
            console.error(`[CacheRedisDriver] forgetByPattern error (pattern: ${match}):`, err);
            throw err;
        }
        console.log(`[CacheRedisDriver] forgetByPattern: pattern=${match} scanned=${totalScanned} deleted=${totalDeleted}`);
        return totalDeleted;
    }
    async keys(limit) {
        await this.ensureReady();
        const keys = [];
        try {
            for await (const item of this.client.scanIterator({ MATCH: `${this.prefix}*`, COUNT: 200 })) {
                if (!item)
                    continue;
                if (Array.isArray(item)) {
                    for (const k of item)
                        if (k)
                            keys.push(k);
                }
                else if (item) {
                    keys.push(item);
                }
                if (limit && keys.length >= limit)
                    break;
            }
        }
        catch (err) {
            console.error('[CacheRedisDriver] keys() error:', err);
        }
        return keys;
    }
    async disconnect() {
        await this.ensureReady();
        await this.client.quit();
    }
}
//# sourceMappingURL=CacheRedisDriver.js.map