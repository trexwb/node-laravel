import { FileDriver } from './CacheFileDriver.js';
import { RedisDriver } from './CacheRedisDriver.js';
import { config } from '../../../bootstrap/configLoader.js';
export class CacheService {
    static instance;
    static getDriver() {
        if (this.instance)
            return this.instance;
        const driverType = config('cache.driver');
        switch (driverType) {
            case 'redis':
                this.instance = new RedisDriver();
                break;
            case 'file':
            default:
                this.instance = new FileDriver();
                break;
        }
        console.log(`[Cache] Using ${driverType} driver`);
        return this.instance;
    }
    static async get(key) {
        return await this.getDriver().get(key);
    }
    static async set(key, value, ttl) {
        return await this.getDriver().set(key, value, ttl);
    }
    static async forget(key) {
        return await this.getDriver().forget(key);
    }
    static async forgetByPattern(pattern) {
        return await this.getDriver().forgetByPattern(pattern);
    }
    static async remember(key, ttl = 0, callback) {
        const val = await this.get(key);
        if (val !== null)
            return val;
        const lockKey = `lock:${key}`;
        const lockTtl = 30;
        let lockAcquired = false;
        try {
            const existingLock = await this.get(lockKey);
            if (existingLock === null) {
                await this.set(lockKey, '1', lockTtl);
                lockAcquired = true;
            }
        }
        catch {
        }
        if (!lockAcquired) {
            for (let i = 0; i < 20; i++) {
                await new Promise((resolve) => setTimeout(resolve, 500));
                const waitingVal = await this.get(key);
                if (waitingVal !== null)
                    return waitingVal;
            }
            console.warn(`[CacheService] Lock wait timeout for key: ${key}, executing callback as fallback`);
        }
        try {
            const freshData = await callback();
            if (freshData !== null && freshData !== undefined && freshData) {
                const expire = ttl === 0 ? 315360000 : ttl;
                await this.set(key, freshData, expire);
            }
            return freshData;
        }
        finally {
            await this.forget(lockKey);
        }
    }
    static async keys(limit) {
        return await this.getDriver().keys(limit);
    }
    static async flush() {
        return await this.getDriver().flush();
    }
    static async safeFlush(pattern) {
        try {
            return await this.forgetByPattern(pattern);
        }
        catch (err) {
            console.error(`[CacheService] safeFlush failed (pattern=${pattern}):`, err);
            return -1;
        }
    }
}
//# sourceMappingURL=CacheService.js.map