import { config } from '../../../bootstrap/configLoader.js';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
export class FileDriver {
    cachePath = path.resolve(__dirname, '../../../', config('cache.path') || 'storage/cache');
    prefix;
    constructor() {
        this.prefix = config('cache.prefix') || '';
    }
    getFilePath(key) {
        const hash = crypto.createHash('md5').update(key).digest('hex');
        return path.join(this.cachePath, hash);
    }
    async get(key) {
        try {
            const data = JSON.parse(await fs.readFile(this.getFilePath(this.prefix + key), 'utf-8'));
            if (Date.now() > data.expire) {
                await this.forget(this.prefix + key);
                return null;
            }
            return data.value;
        }
        catch {
            return null;
        }
    }
    async set(key, value, ttl = 3600) {
        const data = { value, expire: Date.now() + ttl * 1000 };
        await fs.mkdir(this.cachePath, { recursive: true });
        await fs.writeFile(this.getFilePath(this.prefix + key), JSON.stringify(data));
    }
    async forget(key) {
        try {
            await fs.unlink(this.getFilePath(this.prefix + key));
        }
        catch (err) {
            console.error('[CacheFileDriver] forget failed:', key, err);
        }
    }
    async flush() {
        await fs.rm(this.cachePath, { recursive: true, force: true });
    }
    async forgetByPattern(pattern) {
        console.warn(`[CacheFileDriver] forgetByPattern: pattern=[${pattern}] — FileDriver cannot match by pattern, flushing entire cache directory.`);
        await this.flush();
        return 1;
    }
    async keys(limit) {
        try {
            const files = await fs.readdir(this.cachePath);
            const filtered = files.filter((f) => f !== '.' && f !== '..');
            return limit ? filtered.slice(0, limit) : filtered;
        }
        catch {
            return [];
        }
    }
}
//# sourceMappingURL=CacheFileDriver.js.map