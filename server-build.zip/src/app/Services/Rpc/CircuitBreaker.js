export class CircuitBreaker {
    state = 'CLOSED';
    failures = 0;
    lastFailureTime = 0;
    threshold;
    resetTimeout;
    constructor(threshold = 3, resetTimeout = 5000) {
        this.threshold = threshold;
        this.resetTimeout = resetTimeout;
    }
    async execute(fn) {
        if (this.state === 'OPEN') {
            if (Date.now() - this.lastFailureTime > this.resetTimeout) {
                this.state = 'HALF_OPEN';
            }
            else {
                throw new Error('Circuit open');
            }
        }
        try {
            const result = await fn();
            this.success();
            return result;
        }
        catch (err) {
            this.failure();
            throw err;
        }
    }
    success() {
        this.failures = 0;
        this.state = 'CLOSED';
    }
    failure() {
        this.failures++;
        if (this.failures >= this.threshold) {
            this.state = 'OPEN';
            this.lastFailureTime = Date.now();
        }
    }
    getCircuitBreakerState() {
        return this.state;
    }
}
//# sourceMappingURL=CircuitBreaker.js.map