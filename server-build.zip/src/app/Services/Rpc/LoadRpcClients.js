import { Container } from '../../Foundation/Container.js';
import { JsonRpcClient } from './JsonRpcClient.js';
export function loadRpcClientsFromDB(key) {
    let clientPromise = null;
    const getClient = async () => {
        if (!clientPromise) {
            clientPromise = (async () => {
                const provider = Container.resolve('rpc.serverConfigProvider');
                const row = await provider(key);
                if (!row)
                    throw new Error(`RPC server config not found for key: ${key}`);
                return new JsonRpcClient(row);
            })();
        }
        return clientPromise;
    };
    const proxy = new Proxy({}, {
        get(_target, propKey) {
            if (propKey === 'then' || propKey === 'catch' || propKey === 'finally') {
                return undefined;
            }
            return async (...args) => {
                const client = await getClient();
                const methodName = propKey.replace('_', '.');
                return client.call(methodName, args[0] || {});
            };
        },
    });
    return proxy;
}
//# sourceMappingURL=LoadRpcClients.js.map