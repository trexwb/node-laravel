import { CircuitBreaker } from './CircuitBreaker.js';
import { CryptoTool } from '../../Helpers/cryptoTool.js';
export class JsonRpcClient {
    url;
    appId;
    appSecret;
    breaker = new CircuitBreaker();
    constructor(serverConfig) {
        this.url = serverConfig.url;
        this.appId = serverConfig.appId;
        this.appSecret = serverConfig.appSecret;
    }
    generateSignature() {
        const timeStampStr = Math.floor(Date.now() / 1000).toString();
        const appStr = CryptoTool.sha256(`${this.appId}${timeStampStr}`);
        const expectedSecret = CryptoTool.md5(`${appStr}${this.appSecret}`) + timeStampStr;
        return expectedSecret;
    }
    async transport(method, params = {}) {
        const payload = {
            method,
            params,
        };
        try {
            const res = await fetch(this.url, {
                method: 'POST',
                headers: {
                    'App-Id': String(this.appId),
                    'App-Secret': this.generateSignature(),
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            if (!res) {
                throw new Error('Request failed');
            }
            const json = await res.json();
            const rpcResponse = json;
            if (!rpcResponse || typeof rpcResponse !== 'object') {
                throw new Error('Request type failed');
            }
            if (!rpcResponse.code || rpcResponse.code !== 200) {
                return { code: rpcResponse.code, msg: rpcResponse.msg };
            }
            let data = rpcResponse.data || {};
            if (rpcResponse.encryptedData) {
                data = CryptoTool.decrypt(rpcResponse.encryptedData, this.appSecret);
            }
            return data;
        }
        catch (err) {
            return false;
        }
    }
    async withTimeout(promise, ms) {
        const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), ms));
        return Promise.race([promise, timeout]);
    }
    async retry(fn, options = {
        retries: 3,
        baseDelay: 100,
    }) {
        let lastError;
        for (let i = 0; i <= options.retries; i++) {
            try {
                return await fn();
            }
            catch (err) {
                lastError = err;
                if (i === options.retries)
                    break;
                const delay = options.baseDelay * Math.pow(2, i);
                await new Promise((r) => setTimeout(r, delay));
            }
        }
        throw lastError;
    }
    async call(method, params) {
        return this.breaker.execute(() => this.retry(() => this.withTimeout(this.transport(method, params), 3000)));
    }
}
//# sourceMappingURL=JsonRpcClient.js.map