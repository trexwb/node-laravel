export class ExampleUserService {
    users = [
        { id: 1, nickname: '张三', email: 'zhangsan@example.com', status: 1, createdAt: '2026-08-01 10:00:00' },
        { id: 2, nickname: '李四', email: 'lisi@example.com', status: 1, createdAt: '2026-08-05 12:30:00' },
        { id: 3, nickname: '王五', email: 'wangwu@example.com', status: 0, createdAt: '2026-08-10 09:15:00' },
    ];
    seq = 4;
    list(page = 1, pageSize = 10) {
        const start = (page - 1) * pageSize;
        const data = this.users.slice(start, start + pageSize);
        return {
            data,
            meta: {
                total: this.users.length,
                page,
                pageSize,
                totalPages: Math.max(1, Math.ceil(this.users.length / pageSize)),
            },
        };
    }
    find(id) {
        return this.users.find((u) => u.id === id) || null;
    }
    create(input) {
        const now = new Date();
        const user = {
            id: this.seq++,
            nickname: input.nickname,
            email: input.email,
            status: 1,
            createdAt: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`,
        };
        this.users.push(user);
        return user;
    }
}
//# sourceMappingURL=ExampleUserService.js.map