import { Container } from '../../Foundation/Container.js';
import { createLogger } from '../../Helpers/logger.js';
const log = createLogger('DatabaseQueueService');
export class DatabaseQueueService {
    static async dispatch(className, params, options = {}) {
        const { delay = 0, queue = 'default' } = options;
        const store = Container.resolve('queue.store');
        const job = await store.insertJob(className, params, { delay, queue });
        log.info({ jobId: job.id, className, queue, delay }, '任务已写入队列');
        return job;
    }
}
//# sourceMappingURL=DatabaseQueueService.js.map