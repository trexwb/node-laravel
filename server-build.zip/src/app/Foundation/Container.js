export class Container {
    static bindings = new Map();
    static bind(key, resolver) {
        this.bindings.set(key, { resolver, singleton: false });
    }
    static singleton(key, resolver) {
        this.bindings.set(key, { resolver, singleton: true });
    }
    static instance(key, value) {
        this.bindings.set(key, { resolver: () => value, singleton: true, instance: value });
    }
    static has(key) {
        return this.bindings.has(key);
    }
    static resolve(key, fallback) {
        const binding = this.bindings.get(key);
        if (!binding) {
            if (fallback)
                return fallback();
            throw new Error(`[Container] No binding registered for "${key}"`);
        }
        if (binding.singleton && binding.instance !== undefined) {
            return binding.instance;
        }
        const resolved = binding.resolver();
        if (binding.singleton) {
            binding.instance = resolved;
        }
        return resolved;
    }
    static forget(key) {
        this.bindings.delete(key);
    }
    static flush() {
        this.bindings.clear();
    }
}
//# sourceMappingURL=Container.js.map