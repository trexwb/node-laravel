export {};
//# sourceMappingURL=CastInterface.js.map