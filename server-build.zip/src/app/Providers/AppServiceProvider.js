import { registerAllEvents } from '../Events/index.js';
import { createLogger } from '../Helpers/logger.js';
const log = createLogger('AppServiceProvider');
export class AppServiceProvider {
    static boot() {
        registerAllEvents();
        log.info('AppServiceProvider 已加载');
    }
}
//# sourceMappingURL=AppServiceProvider.js.map