import { Handler } from '../app/Exceptions/Handler.js';
import { forceHttps } from '../app/Http/Middleware/ForceHttps.js';
import { responseWrapper } from '../app/Http/Middleware/ResponseWrapper.js';
import { traceIdMiddleware } from '../app/Http/Middleware/TraceId.js';
import { AppServiceProvider } from '../app/Providers/AppServiceProvider.js';
import { config, validateSecurityConfig } from './configLoader.js';
import { eventBus } from './events.js';
import knexConfig from '../database/knexfile.js';
import { createApiRoutes } from '../routes/api.js';
import consoleRoutes from '../routes/console.js';
import { createEventRoutes } from '../routes/event.js';
import webRoutes from '../routes/web.js';
import { createLogger } from '../app/Helpers/logger.js';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import knex from 'knex';
import { Model } from 'objection';
const log = createLogger('Bootstrap');
const db = knex(knexConfig);
const app = express();
app.set('trust proxy', 1);
Model.knex(db);
export async function bootstrap(appInstance) {
    AppServiceProvider.boot();
    const appConfig = config('app');
    const appKey = appConfig?.security?.app_key;
    const appIv = appConfig?.security?.app_iv;
    if (appConfig.env === 'production') {
        validateSecurityConfig();
    }
    else if (!appKey || !appIv) {
        console.warn('[Bootstrap] APP_KEY/APP_IV not configured — encryption features will not work properly');
    }
    if (appConfig.env === 'production') {
        appConfig?.ssl?.enabled && appInstance.use(forceHttps);
    }
    appInstance.use(helmet());
    appInstance.use(express.json({ limit: '10mb' }));
    appInstance.use(express.static('public'));
    appInstance.use(express.urlencoded({ limit: '10mb', extended: true }));
    const corsOrigins = config('app.cors.origins') || ['*'];
    if (appConfig.env === 'production' && corsOrigins.includes('*')) {
        console.warn('[Bootstrap] CORS origins is "*" in production — 建议配置 CORS_ORIGINS 白名单');
    }
    const corsMethods = config('app.cors.methods') || ['GET', 'POST', 'OPTIONS', 'PUT', 'DELETE', 'PATCH'];
    const corsAllowedHeaders = config('app.cors.allowedHeaders') || ['Content-Type'];
    appInstance.use(cors({
        origin: corsOrigins.includes('*') ? true : corsOrigins,
        methods: corsMethods,
        allowedHeaders: corsAllowedHeaders,
        credentials: !corsOrigins.includes('*'),
    }));
    appInstance.use((req, res, next) => {
        if (req.method === 'OPTIONS') {
            res.sendStatus(204);
        }
        else {
            req.eventEmitter = eventBus;
            next();
        }
    });
    appInstance.use(traceIdMiddleware);
    appInstance.use(responseWrapper);
    const [apiRoutes, eventRoutes] = await Promise.all([createApiRoutes(), createEventRoutes()]);
    appInstance.use('/api', apiRoutes);
    appInstance.use('/event', eventRoutes);
    appInstance.use('/console', consoleRoutes);
    appInstance.use('/', webRoutes);
    appInstance.use(Handler.render);
    log.info('全局异常处理器已就绪');
}
export const container = {
    app,
    db,
    events: eventBus,
    config,
};
//# sourceMappingURL=app.js.map