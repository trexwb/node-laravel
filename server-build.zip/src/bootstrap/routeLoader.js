import fs from 'node:fs/promises';
import path from 'node:path';
import { Router } from 'express';
export async function loadDynamicRoutes(basePath, urlPrefix = '') {
    const router = Router();
    async function getFiles(dir) {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        const files = await Promise.all(entries.map((entry) => {
            const res = path.resolve(dir, entry.name);
            return entry.isDirectory() ? getFiles(res) : res;
        }));
        return files.flat().filter(file => /\.(ts|js)$/.test(file) && !file.endsWith('.d.ts'));
    }
    const files = await getFiles(basePath);
    for (const file of files) {
        const relativePath = path.relative(basePath, file);
        const pathParsed = path.parse(relativePath);
        const routePath = path.join(urlPrefix, pathParsed.dir, pathParsed.name === 'index' ? '' : pathParsed.name).replace(/\\/g, '/');
        const module = await import(`file://${file}`);
        const routeHandler = module.default || module;
        if (typeof routeHandler === 'function' || Object.getPrototypeOf(routeHandler) === Router) {
            router.use(`/${routePath}`, routeHandler);
        }
    }
    return router;
}
//# sourceMappingURL=routeLoader.js.map