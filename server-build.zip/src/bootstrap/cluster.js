import cluster from 'node:cluster';
import os from 'node:os';
import { config } from './configLoader.js';
import { logger } from '../app/Helpers/logger.js';
export function runWithCluster(boot, options = {}) {
    const { enabled = config('app.cluster.enabled'), workers } = options;
    const wsEnabled = config('app.ws.enabled');
    const wsMode = config('app.ws.mode');
    if (process.env.NODE_IS_WS === 'true') {
        boot(false);
        return;
    }
    if (!enabled || !cluster.isPrimary) {
        boot(true);
        return;
    }
    const numCPUs = workers === 'auto' || !workers
        ? os.cpus().length
        : parseInt(String(workers)) || os.cpus().length;
    logger.info(`[Cluster] Master 进程 ${process.pid} 启动，正在调度 ${numCPUs} 个 Worker...`);
    if (wsEnabled && wsMode === 'standalone') {
        const wsEnv = { ...process.env, NODE_IS_WS: 'true' };
        const wsWorker = cluster.fork(wsEnv);
        wsWorker.on('online', () => {
            logger.info(`[Cluster] WebSocket Worker ${wsWorker.process.pid} 已启动`);
        });
        wsWorker.on('exit', (code, signal) => {
            logger.warn(`[Cluster] WebSocket Worker 退出 (code=${code} signal=${signal})，正在重启...`);
            cluster.fork(wsEnv);
        });
    }
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork();
    }
    cluster.on('exit', (worker, code, signal) => {
        if (process.env.NODE_IS_WS === 'true') {
            return;
        }
        logger.warn(`[Cluster] Worker ${worker.process.pid} 退出 (code=${code} signal=${signal})，` +
            `正在重新拉起...`);
        cluster.fork();
    });
    cluster.on('fork', (worker) => {
        logger.debug(`[Cluster] Worker ${worker.process.pid} 正在启动...`);
    });
    cluster.on('online', (worker) => {
        logger.info(`[Cluster] Worker ${worker.process.pid} 已就绪`);
    });
}
//# sourceMappingURL=cluster.js.map