import { EventEmitter } from 'node:events';
import { config } from './configLoader.js';
class LocalEventBus extends EventEmitter {
    constructor() {
        super();
        this.setMaxListeners(50);
    }
}
export const eventBus = new LocalEventBus();
let redisClient = null;
let redisSubscriber = null;
let crossProcessBus = null;
async function getRedisClient() {
    if (redisClient)
        return redisClient;
    const redisEnabled = config('cache.driver') === 'redis' && config('cache.host');
    if (!redisEnabled) {
        return null;
    }
    try {
        const { createClient } = await import('redis');
        const host = config('cache.host');
        const port = config('cache.port');
        const password = config('cache.passwd');
        redisClient = createClient({
            password: password || undefined,
            socket: { host, port },
        });
        redisClient.on('error', (err) => {
            console.error('[CrossProcessBus] Redis Client Error:', err.message);
        });
        await redisClient.connect();
        console.log('[CrossProcessBus] Redis 连接成功');
        return redisClient;
    }
    catch (err) {
        console.warn('[CrossProcessBus] Redis 连接失败，跨进程事件将不可用:', err.message);
        return null;
    }
}
async function getRedisSubscriber() {
    if (redisSubscriber)
        return redisSubscriber;
    const client = await getRedisClient();
    if (!client)
        return null;
    redisSubscriber = client.duplicate();
    await redisSubscriber.connect();
    return redisSubscriber;
}
export async function createCrossProcessEventBus(options) {
    if (crossProcessBus)
        return crossProcessBus;
    const subscriber = await getRedisSubscriber();
    if (!subscriber) {
        console.warn('[CrossProcessBus] Redis 不可用，返回空实现');
        return {
            publish: async (_channel, _data) => { },
            subscribe: (_channel, _handler) => { },
        };
    }
    const localHandlers = new Map();
    await subscriber.subscribe(options.channel, (message) => {
        try {
            const { event, args } = JSON.parse(message);
            const handlers = localHandlers.get(event) || [];
            handlers.forEach(handler => {
                try {
                    handler(...args);
                }
                catch (e) {
                    console.error(`[CrossProcessBus] Handler error for event "${event}":`, e);
                }
            });
        }
        catch (e) {
            console.error('[CrossProcessBus] 消息解析失败:', e);
        }
    });
    crossProcessBus = {
        publish: async (event, ...args) => {
            eventBus.emit(event, ...args);
            const publisher = await getRedisClient();
            if (publisher) {
                await publisher.publish(options.channel, JSON.stringify({ event, args }));
            }
        },
        subscribe: (event, handler) => {
            if (!localHandlers.has(event)) {
                localHandlers.set(event, []);
            }
            localHandlers.get(event).push(handler);
        },
    };
    console.log(`[CrossProcessBus] 跨进程事件总线已就绪 (channel: ${options.channel})`);
    return crossProcessBus;
}
export async function broadcast(event, ...args) {
    if (crossProcessBus) {
        await crossProcessBus.publish(event, ...args);
    }
    else {
        eventBus.emit(event, ...args);
    }
}
//# sourceMappingURL=events.js.map