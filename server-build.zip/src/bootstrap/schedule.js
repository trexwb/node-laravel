import { Kernel } from '../app/Console/Kernel.js';
import { createLogger } from '../app/Helpers/logger.js';
import cluster from 'node:cluster';
const log = createLogger('Scheduler');
export function bootScheduling() {
    if (cluster.isPrimary) {
        Kernel.listen();
        Kernel.schedule();
        log.info('计划任务调度器已启动');
    }
}
//# sourceMappingURL=schedule.js.map