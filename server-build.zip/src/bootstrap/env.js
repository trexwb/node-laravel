import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({
    path: path.resolve(__dirname, '../../.env'),
});
export function env(key, defaultValue) {
    const value = process.env[key];
    if (value === undefined || value === '') {
        return defaultValue;
    }
    if (value.toLowerCase() === 'true')
        return true;
    if (value.toLowerCase() === 'false')
        return false;
    if (/^\d+$/.test(value)) {
        return parseInt(value, 10);
    }
    if (/^\d+\.\d+$/.test(value)) {
        return parseFloat(value);
    }
    return value;
}
export function envString(key, defaultValue = '') {
    const value = env(key, defaultValue);
    return String(value ?? defaultValue);
}
export function envNumber(key, defaultValue = 0) {
    const value = env(key, defaultValue);
    const num = Number(value);
    return isNaN(num) ? defaultValue : num;
}
export function envBoolean(key, defaultValue = false) {
    const value = env(key, defaultValue);
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string') {
        return value.toLowerCase() === 'true';
    }
    return defaultValue;
}
export const envLoaded = true;
export {};
//# sourceMappingURL=env.js.map