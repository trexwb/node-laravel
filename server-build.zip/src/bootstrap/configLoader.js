import app from '../config/app.js';
import database from '../config/database.js';
import cache from '../config/cache.js';
import * as _ from 'lodash-es';
const configs = {
    app,
    database,
    cache
};
export function validateSecurityConfig() {
    const appSecurity = configs.app?.security;
    if (!appSecurity) {
        throw new Error('[FATAL] app.security 配置缺失，请检查 config/app.ts\n' +
            '提示：APP_KEY 和 APP_IV 必须通过环境变量配置，禁止使用硬编码默认值');
    }
    const { app_key, app_iv } = appSecurity;
    if (!app_key || app_key.trim() === '') {
        throw new Error('[FATAL] APP_KEY 环境变量未设置\n' +
            '请在 .env 中添加：APP_KEY=<32位随机字符串>\n' +
            '示例：APP_KEY=$(openssl rand -hex 32)');
    }
    if (!app_iv || app_iv.trim() === '') {
        throw new Error('[FATAL] APP_IV 环境变量未设置\n' +
            '请在 .env 中添加：APP_IV=<16位随机字符串>\n' +
            '示例：APP_IV=$(openssl rand -hex 16)');
    }
    if (Buffer.byteLength(app_key) !== 32) {
        console.warn(`[WARN] APP_KEY 长度应为 32 字节（当前 ${Buffer.byteLength(app_key)} 字节），` +
            `已自动补齐或截断处理，但建议使用 32 字节密钥`);
    }
}
export function config(path, defaultValue = null) {
    return _.get(configs, path, defaultValue);
}
export function isProduction() {
    return config('app.env') === 'production';
}
export function isDebug() {
    return config('app.debugger') === true;
}
//# sourceMappingURL=configLoader.js.map