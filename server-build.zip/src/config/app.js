export default {
    name: process.env.APP_NAME || 'NodeLaravel',
    env: process.env.APP_ENV || 'development',
    debugger: process.env.APP_DEBUG === 'true',
    timezone: process.env.TIME_ZONE || 'Asia/Shanghai',
    url: process.env.APP_URL || 'localhost',
    http_port: parseInt(process.env.HTTP_PORT || process.env.PORT || '80'),
    https_port: parseInt(process.env.HTTPS_PORT || '443'),
    upload_path: process.env.UPLOAD_PATH || 'storage/uploads',
    ws: {
        port: parseInt(process.env.WS_PORT || '8080'),
        path: process.env.WS_PATH || '/socket.io',
        enabled: process.env.WS_ENABLED === 'true',
        mode: process.env.WS_MODE || (process.env.CLUSTER_ENABLED === 'true' ? 'standalone' : 'shared'),
    },
    ssl: {
        key: process.env.SSL_KEY_PATH || '../certs/server.key',
        cert: process.env.SSL_CERT_PATH || '../certs/server.crt',
        enabled: process.env.SSL_ENABLED === 'true'
    },
    front: {
        port: parseInt(process.env.FRONT_PORT || '3000'),
    },
    cluster: {
        enabled: process.env.CLUSTER_ENABLED === 'true',
        workers: process.env.CLUSTER_WORKERS === 'auto' ? 'auto' : parseInt(process.env.CLUSTER_WORKERS || '1')
    },
    security: {
        verify_signature: process.env.VERIFY_SIGNATURE === 'true',
        request_encrypt: process.env.REQUEST_ENCRYPT === 'true',
        return_encrypt: process.env.RETURN_ENCRYPT === 'true',
        token_time: parseInt(process.env.TOKEN_TIME || '1800'),
        app_key: process.env.APP_KEY,
        app_iv: process.env.APP_IV,
    },
    cors: {
        origins: process.env.CORS_ORIGINS
            ? process.env.CORS_ORIGINS.split(',').map(s => s.trim())
            : ['*'],
        methods: ['GET', 'POST', 'OPTIONS', 'PUT', 'DELETE', 'PATCH'],
        allowedHeaders: ['Content-Type', 'Authorization', 'App-Id', 'App-Secret', 'X-Request-Id', 'X-Sign'],
    },
    log: {
        level: process.env.LOG_LEVEL || (process.env.APP_ENV === 'production' ? 'info' : 'debug'),
    },
};
//# sourceMappingURL=app.js.map